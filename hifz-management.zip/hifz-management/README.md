# Hifz Management

This is a separate Hifz-only copy of the web portal, Express API, and SQL
migration history. It contains no live environment file, database dump, user
data, or institution artwork. Changes here do not change the source project.

## Included portals

- `/admin` for administrators and controllers, including Hifz setup.
- `/staff` for mentors and staff.
- `/principal` for principals and vice principals. Both roles use the same
  leadership interface, served from the shared staff pages.

This copy has Hifz student registration, mentor assignment, sessions,
attendance, recording, progress, and exams. It has no parent login, finance or
WhatsApp workflow, mobile client, or school/madrasa setup option. Contact
details remain available in internal student and discipline records.

## Before running

1. Create a **new** Supabase project and PostgreSQL database. Do not reuse the
   source project's URL, database, service role key, or JWT secret.
2. Copy `.env.example` to `.env.local` and enter only the new project's values.
3. Install dependencies in this folder and its `backend` subfolder:
   `npm ci`, then `cd backend` and `npm ci`.
4. Set up the new database schema and at least one admin account before login.
   The SQL under `supabase/migrations` is the original incremental history; it
   assumes foundational tables such as `students`, `staff`, and `profiles`
   already exist. It is **not** a clean initial migration for a blank database.
   A new baseline schema is required before this copy can serve real users.
5. From this folder, run `npm run dev` to start the web and API servers.

Legacy finance, mobile, and notification table migrations remain in the SQL
history because later migrations may depend on that history. Their web pages,
API routes, and workers are disabled. Build a clean database baseline when
continuing this project; do not apply this history blindly to a production
database.

## Checks

- Frontend: `npx tsc --noEmit` and `npm run build`.
- Backend: `cd backend` then `npm run check` after installing dependencies.

## Continuing development

Open this folder as its own project in Codex or your editor. Keep its Git
repository, deployment, database, and environment variables separate from the
source project. Replace the generic SVG artwork and the displayed project name
when you choose the new institution's branding.
