import { Request, Response } from 'express';
import { db } from '../config/db';
import { getAcademicYearContext } from '../utils/academic-year';

// --- Global Exams ---

export const getExams = async (req: Request, res: Response) => {
    try {
        let query = "SELECT * FROM exams WHERE LOWER(department) = 'hifz'";
        const params: any[] = [];
        query += ' ORDER BY start_date DESC';

        const result = await db.query(query, params);
        res.json({ success: true, exams: result.rows });
    } catch (err) {
        console.error('Error fetching exams:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch exams' });
    }
};

export const createExam = async (req: Request, res: Response) => {
    try {
        const { title, start_date, end_date, is_active } = req.body;
        
        const result = await db.query(
            `INSERT INTO exams (title, department, type, start_date, end_date, is_active)
             VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
            [title, 'Hifz', 'Hifz', start_date, end_date || null, is_active ?? true]
        );
        
        res.status(201).json({ success: true, exam: result.rows[0] });
    } catch (err) {
        console.error('Error creating exam:', err);
        res.status(500).json({ success: false, error: 'Failed to create exam' });
    }
};

// --- Single Exam Details ---

export const getExamDetails = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        
        const examResult = await db.query("SELECT * FROM exams WHERE id = $1 AND LOWER(department) = 'hifz'", [id]);
        if (examResult.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Exam not found' });
        }

        const subjectsResult = await db.query('SELECT * FROM exam_subjects WHERE exam_id = $1 ORDER BY created_at', [id]);

        res.json({
            success: true,
            exam: examResult.rows[0],
            subjects: subjectsResult.rows
        });
    } catch (err) {
        console.error('Error fetching exam details:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch exam details' });
    }
};

export const updateExamStatus = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { is_active } = req.body;
        
        const result = await db.query(
            "UPDATE exams SET is_active = $1 WHERE id = $2 AND LOWER(department) = 'hifz' RETURNING *",
            [is_active, id]
        );
        
        res.json({ success: true, exam: result.rows[0] });
    } catch (err) {
        console.error('Error updating exam status:', err);
        res.status(500).json({ success: false, error: 'Failed to update exam status' });
    }
};

export const deleteExam = async (req: Request, res: Response) => {
    const client = await db.getClient();
    try {
        await client.query('BEGIN');
        const examResult = await client.query("SELECT id, title FROM exams WHERE id = $1 AND LOWER(department) = 'hifz' FOR UPDATE", [req.params.id]);
        if (examResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ success: false, error: 'Exam not found' });
        }
        const counts = await client.query(
            `SELECT (SELECT COUNT(*)::int FROM exam_subjects WHERE exam_id = $1) AS subjects,
                    (SELECT COUNT(*)::int FROM exam_results WHERE exam_id = $1) AS results`,
            [req.params.id]
        );
        await client.query('DELETE FROM exams WHERE id = $1', [req.params.id]);
        await client.query('COMMIT');
        res.json({ success: true, deleted: { exam: examResult.rows[0], ...counts.rows[0] } });
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('Error deleting exam:', err);
        res.status(500).json({ success: false, error: 'Failed to permanently delete exam' });
    } finally {
        client.release();
    }
};

// --- Subjects ---

export const addSubject = async (req: Request, res: Response) => {
    try {
        const { id } = req.params; // exam_id
        const { name, max_marks, min_marks } = req.body;
        
        const cleanName = String(name || '').trim();
        const max = Number(max_marks);
        const min = Number(min_marks);
        const cleanStandard = 'Hifz';
        if (!cleanName || !Number.isFinite(max) || max <= 0 || !Number.isFinite(min) || min < 0 || min > max) {
            return res.status(400).json({ success: false, error: 'Subject, maximum marks, and a valid pass mark are required' });
        }
        const exam = await db.query("SELECT 1 FROM exams WHERE id = $1 AND LOWER(department) = 'hifz'", [id]);
        if (!exam.rows.length) return res.status(404).json({ success: false, error: 'Exam not found' });
        const duplicate = await db.query(
            'SELECT 1 FROM exam_subjects WHERE exam_id = $1 AND LOWER(name) = LOWER($2) AND standard = $3',
            [id, cleanName, cleanStandard]
        );
        if (duplicate.rows.length) {
            return res.status(409).json({ success: false, error: `${cleanName} is already configured for ${cleanStandard}` });
        }
        const result = await db.query(
            `INSERT INTO exam_subjects (exam_id, name, max_marks, min_marks, standard)
             VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [id, cleanName, max, min, cleanStandard]
        );
        
        res.status(201).json({ success: true, subject: result.rows[0] });
    } catch (err) {
        console.error('Error adding subject:', err);
        res.status(500).json({ success: false, error: 'Failed to add subject' });
    }
};

export const deleteSubject = async (req: Request, res: Response) => {
    try {
        const { subject_id } = req.params;
        
        await db.query('DELETE FROM exam_subjects WHERE id = $1', [subject_id]);
        
        res.json({ success: true });
    } catch (err) {
        console.error('Error deleting subject:', err);
        res.status(500).json({ success: false, error: 'Failed to delete subject' });
    }
};

// --- Marks / Results ---

export const getExamMarks = async (req: Request, res: Response) => {
    try {
        const { id } = req.params; // exam_id
        const { subject_id } = req.query;
        
        let query = 'SELECT subject_id, student_id, marks_obtained, remarks FROM exam_results WHERE exam_id = $1';
        const params: any[] = [id];
        
        if (subject_id) {
            query += ' AND subject_id = $2';
            params.push(subject_id);
        }
        
        const result = await db.query(query, params);
        res.json({ success: true, marks: result.rows });
    } catch (err) {
        console.error('Error fetching exam marks:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch exam marks' });
    }
};

export const upsertExamMarks = async (req: Request, res: Response) => {
    try {
        const { id } = req.params; // exam_id
        const { updates } = req.body; // Array of marks
        
        if (!Array.isArray(updates) || updates.length === 0) {
            return res.status(400).json({ success: false, error: 'At least one mark is required' });
        }
        const client = await db.getClient();
        try {
            await client.query('BEGIN');

            const subjectIds = [...new Set(updates.map((u: any) => u.subject_id))];
            const subjectResult = await client.query(
                'SELECT id, standard, max_marks FROM exam_subjects WHERE exam_id = $1 AND id = ANY($2::uuid[])',
                [id, subjectIds]
            );
            const subjectMap = new Map(subjectResult.rows.map(row => [row.id, row]));
            if (subjectMap.size !== subjectIds.length) throw new Error('One or more subjects do not belong to this exam');
            
            for (const update of updates) {
                const subject = subjectMap.get(update.subject_id);
                const marks = Number(update.marks_obtained);
                if (!Number.isFinite(marks) || marks < 0 || marks > Number(subject.max_marks)) {
                    throw new Error(`Marks must be between 0 and ${subject.max_marks}`);
                }
                const placement = await client.query(
                    "SELECT 1 FROM students WHERE adm_no = $1 AND status = 'active' AND standard = 'Hifz' LIMIT 1",
                    [update.student_id]
                );
                if (!placement.rows.length) throw new Error('Student is not active in Hifz');
                await client.query(
                    `INSERT INTO exam_results (exam_id, subject_id, student_id, marks_obtained, remarks, grader_id)
                     VALUES ($1, $2, $3, $4, $5, $6)
                     ON CONFLICT (student_id, subject_id) 
                     DO UPDATE SET 
                        marks_obtained = EXCLUDED.marks_obtained,
                        remarks = EXCLUDED.remarks,
                        grader_id = EXCLUDED.grader_id`,
                    [id, update.subject_id, update.student_id, marks, update.remarks || null, update.grader_id || null]
                );
            }
            
            await client.query('COMMIT');
            res.json({ success: true });
        } catch (e) {
            await client.query('ROLLBACK');
            throw e;
        } finally {
            client.release();
        }
    } catch (err: any) {
        console.error('Error upserting exam marks:', err);
        res.status(400).json({ success: false, error: err?.message || 'Failed to save marks' });
    }
};

export const getStudentsForExamMarks = async (req: Request, res: Response) => {
    try {
        const result = await db.query(
            "SELECT adm_no, name, 'Hifz' AS standard, 'Hifz' AS hifz_standard FROM students WHERE status = 'active' AND standard = 'Hifz' ORDER BY name"
        );
        
        res.json({ success: true, students: result.rows });
    } catch (err) {
        console.error('Error fetching students for exams:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch students' });
    }
};
