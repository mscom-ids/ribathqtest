"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import api from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

type Student = {
  adm_no: string
  name: string
  dob?: string | null
  father_name?: string | null
  phone?: string | null
  status?: string | null
  photo_url?: string | null
  hifz_mentor_id?: string | null
}
type Mentor = { id: string; name: string }
type HifzLog = {
  id: string
  entry_date: string
  mode?: string | null
  juz_number?: number | null
  pages_recited?: number | null
  recorded_by_name?: string | null
}

export function StudentDetailView({ canEdit = true, backTo = "/admin/students" }: { canEdit?: boolean; backTo?: string }) {
  const params = useParams<{ id: string }>()
  const studentId = String(params.id || "")
  const [student, setStudent] = useState<Student | null>(null)
  const [mentors, setMentors] = useState<Mentor[]>([])
  const [logs, setLogs] = useState<HifzLog[]>([])
  const [form, setForm] = useState({ name: "", dob: "", father_name: "", phone: "", hifz_mentor_id: "" })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!studentId) return
    let active = true
    async function load() {
      setLoading(true)
      try {
        const [studentResponse, mentorResponse, logResponse] = await Promise.all([
          api.get(`/students/${encodeURIComponent(studentId)}`),
          api.get("/students/staff").catch(() => ({ data: { staff: [] } })),
          api.get("/hifz/logs", { params: { student_id: studentId, limit: 30 } }),
        ])
        if (!active) return
        const next: Student = studentResponse.data.student
        setStudent(next)
        setForm({
          name: next.name || "",
          dob: next.dob?.slice(0, 10) || "",
          father_name: next.father_name || "",
          phone: next.phone || "",
          hifz_mentor_id: next.hifz_mentor_id || "",
        })
        setMentors(mentorResponse.data.staff || [])
        setLogs(logResponse.data.logs || [])
        setError("")
      } catch (cause: any) {
        if (active) setError(cause?.response?.data?.error || "Unable to load student")
      } finally {
        if (active) setLoading(false)
      }
    }
    void load()
    return () => { active = false }
  }, [studentId])

  async function save() {
    if (!studentId || !form.name.trim()) return
    setSaving(true)
    try {
      const response = await api.put(`/students/${encodeURIComponent(studentId)}`, {
        name: form.name.trim(),
        dob: form.dob || null,
        father_name: form.father_name || null,
        phone: form.phone || null,
        hifz_mentor_id: form.hifz_mentor_id || null,
        standard: "Hifz",
      })
      setStudent(response.data.student)
      setError("")
    } catch (cause: any) {
      setError(cause?.response?.data?.error || "Unable to save student")
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <p className="p-6 text-slate-500">Loading student...</p>
  if (!student) return <p className="p-6 text-red-700">{error || "Student not found"}</p>

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-teal-700">Hifz student</p>
          <h1 className="text-2xl font-bold text-slate-900">{student.name}</h1>
          <p className="text-sm text-slate-500">Admission {student.adm_no} · {student.status || "active"}</p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline"><Link href={backTo}>All students</Link></Button>
          {canEdit && <Button asChild><Link href="/admin/hifz/tracking">Hifz recording</Link></Button>}
        </div>
      </div>
      {error && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      <Card>
        <CardHeader><CardTitle>Student and mentor</CardTitle></CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <label className="space-y-1 text-sm">Name<Input value={form.name} disabled={!canEdit} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
          <label className="space-y-1 text-sm">Date of birth<Input type="date" value={form.dob} disabled={!canEdit} onChange={e => setForm({ ...form, dob: e.target.value })} /></label>
          <label className="space-y-1 text-sm">Guardian name<Input value={form.father_name} disabled={!canEdit} onChange={e => setForm({ ...form, father_name: e.target.value })} /></label>
          <label className="space-y-1 text-sm">Guardian phone<Input value={form.phone} disabled={!canEdit} onChange={e => setForm({ ...form, phone: e.target.value })} /></label>
          <label className="space-y-1 text-sm sm:col-span-2">Hifz mentor
            <select className="mt-1 h-10 w-full rounded-md border border-slate-300 bg-white px-3" value={form.hifz_mentor_id} disabled={!canEdit} onChange={e => setForm({ ...form, hifz_mentor_id: e.target.value })}>
              <option value="">Unassigned</option>
              {mentors.map(mentor => <option key={mentor.id} value={mentor.id}>{mentor.name}</option>)}
            </select>
          </label>
          {canEdit && <div className="sm:col-span-2"><Button disabled={saving || !form.name.trim()} onClick={save}>{saving ? "Saving..." : "Save changes"}</Button></div>}
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Recent Hifz entries</CardTitle></CardHeader>
        <CardContent>
          {logs.length === 0 ? <p className="text-sm text-slate-500">No Hifz entries yet.</p> : (
            <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b"><th className="py-2">Date</th><th>Mode</th><th>Juz</th><th>Pages</th><th>Recorded by</th></tr></thead><tbody>{logs.map(log => <tr key={log.id} className="border-b"><td className="py-2">{log.entry_date?.slice(0, 10)}</td><td>{log.mode || "—"}</td><td>{log.juz_number ?? "—"}</td><td>{log.pages_recited ?? "—"}</td><td>{log.recorded_by_name || "—"}</td></tr>)}</tbody></table></div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
