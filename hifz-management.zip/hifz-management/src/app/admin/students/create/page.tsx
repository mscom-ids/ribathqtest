
"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"
import { PhoneInput, validatePhone } from "@/components/ui/phone-input"

import { Button } from "@/components/ui/button"
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { DateTextInput } from "@/components/ui/date-text-input"
import { Input } from "@/components/ui/input"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import api from "@/lib/api"

const formSchema = z.object({
    adm_no: z.string().min(1, "Admission number is required"),
    name: z.string().min(2),
    admission_date: z.string().optional(),
    dob: z.string().optional(),
    address: z.string().optional(),
    father_name: z.string().optional(),
    email: z.string().email().optional().or(z.literal('')),
    batch_year: z.string().optional().or(z.literal('')),
    standard: z.string().optional(),
    hifz_mentor_id: z.string().optional(),
    phone_number: z.string().optional().refine(
        (v) => validatePhone(v) === true,
        { message: "Phone must be 8–15 digits" }
    ),
})

type StaffOption = { id: string; name: string }

export default function CreateStudentPage() {
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [staff, setStaff] = useState<StaffOption[]>([])
    const [suggestedId, setSuggestedId] = useState("H001")
    const [idError, setIdError] = useState("")

    useEffect(() => {
        async function loadStaff() {
            try {
                const res = await api.get("/students/staff")
                if (res.data.success) {
                    setStaff(res.data.staff)
                }
            } catch (err) { console.error(err) }
        }
        async function loadNextId() {
            try {
                const res = await api.get("/students/next-id")
                if (res.data.success) {
                    setSuggestedId(res.data.nextId)
                }
            } catch (err) { console.error(err) }
        }
        loadStaff()
        loadNextId()
    }, [])

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            adm_no: "",
            name: "",
            admission_date: new Date().toISOString().slice(0, 10),
            dob: "",
            address: "",
            father_name: "",
            email: "",
            batch_year: "",
            standard: "Hifz",
            hifz_mentor_id: "unassigned",
            phone_number: ""
        },
    })

    const [photoUploading, setPhotoUploading] = useState(false)
    const [photoUrl, setPhotoUrl] = useState<string | null>(null)

    async function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
        if (!e.target.files || e.target.files.length === 0) return;
        const file = e.target.files[0];
        const studentName = form.getValues("name").trim();
        const admissionNumber = form.getValues("adm_no").trim().toUpperCase();
        if (!studentName || !/^H\d{3}$/.test(admissionNumber)) {
            alert("Enter the student name and an admission number like H123 before uploading a photo.");
            e.target.value = "";
            return;
        }
        setPhotoUploading(true);

        const formData = new FormData();
        formData.append('avatar', file);
        formData.append('student_name', studentName);
        formData.append('student_admission_number', admissionNumber);

        try {
            const res = await api.post('/upload/avatar', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            if (res.data.success) {
                setPhotoUrl(res.data.filePath);
            } else {
                alert("Failed to upload photo: " + res.data.error);
            }
        } catch (error: any) {
            console.error("Photo upload error:", error);
            alert("Upload failed: " + (error.response?.data?.error || error.message));
        } finally {
            setPhotoUploading(false);
        }
    }

    async function onSubmit(values: z.infer<typeof formSchema>) {
        setLoading(true)
        setIdError("")

        const admNo = values.adm_no.trim()

        try {
            const response = await api.post("/students", {
                admission_number: admNo,
                full_name: values.name,
                admission_date: values.admission_date || null,
                date_of_birth: values.dob || null,
                address_line: values.address || null,
                parent_name: values.father_name || null,
                email: values.email || null,
                batch_year: values.batch_year || null,
                class: values.standard || null,
                hifz_mentor_id: values.hifz_mentor_id === "unassigned" ? null : values.hifz_mentor_id,
                photo_url: photoUrl,
                status: "active",
                phone_number: values.phone_number || null
            })

            if (response.data.success) {
               router.push("/admin/students")
            } else {
               setIdError(response.data.error || "Failed to create student")
            }
        } catch (error: any) {
            console.error("Create Student Error:", error)
            setIdError(error.response?.data?.error || "Failed to create student")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="max-w-2xl mx-auto space-y-6">
            <h1 className="text-2xl font-bold text-emerald-900 dark:text-emerald-50">Add New Student</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Student Details</CardTitle>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">

                            <div className="flex flex-col space-y-2">
                                <FormLabel>Student Photo</FormLabel>
                                <div className="flex items-center gap-4">
                                    {photoUrl && (
                                        <img
                                            src={photoUrl}
                                            alt="Preview"
                                            className="h-16 w-16 rounded-full object-cover border"
                                        />
                                    )}
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        onChange={handlePhotoUpload}
                                        disabled={photoUploading}
                                    />
                                </div>
                                {photoUploading && <p className="text-xs text-muted-foreground">Uploading...</p>}
                            </div>

                            {/* Admission Number - Manual Entry */}
                            <FormField
                                control={form.control}
                                name="adm_no"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Admission Number (ID)</FormLabel>
                                        <FormControl>
                                            <Input placeholder={suggestedId} {...field} />
                                        </FormControl>
                                        <FormDescription>
                                            Enter manually. Suggested next: <button type="button" className="text-emerald-500 hover:underline font-mono" onClick={() => form.setValue('adm_no', suggestedId)}>{suggestedId}</button> — click to use
                                        </FormDescription>
                                        {idError && <p className="text-sm text-red-500 font-medium">{idError}</p>}
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Full Name</FormLabel>
                                        <FormControl>
                                            <Input placeholder="John Doe" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            <div className="grid grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="admission_date"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Admission Date</FormLabel>
                                            <FormControl>
                                                <Input type="date" {...field} />
                                            </FormControl>
                                            <FormDescription>Date the student joined the institution</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="dob"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Date of Birth</FormLabel>
                                            <FormControl>
                                                <DateTextInput {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="standard"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Program</FormLabel>
                                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Hifz" />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    <SelectItem value="Hifz">Hifz</SelectItem>
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="batch_year"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Batch Year</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>

                            <div className="grid grid-cols-1 gap-4">
                                <FormField
                                    control={form.control}
                                    name="hifz_mentor_id"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Hifz Mentor</FormLabel>
                                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select Mentor" />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    <SelectItem value="unassigned" className="text-red-500 font-medium">Unassign Mentor</SelectItem>
                                                    {staff.map((s) => (
                                                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="father_name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Father's Name</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="email"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Parent Email</FormLabel>
                                            <FormControl>
                                                <Input type="email" placeholder="parent@example.com" {...field} />
                                            </FormControl>
                                            <FormDescription>Optional contact number for internal records.</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>

                            <FormField
                                control={form.control}
                                name="phone_number"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Phone Number</FormLabel>
                                        <PhoneInput
                                            value={field.value ?? ""}
                                            onChange={field.onChange}
                                            disabled={loading}
                                        />
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            <Button type="submit" disabled={loading} className="w-full bg-emerald-600 hover:bg-emerald-700">
                                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Create Student
                            </Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
        </div>
    )
}
