import Link from "next/link"
import {
  BookOpen, CalendarDays, ClipboardCheck, FileText, GraduationCap,
  MessageCircle, ShieldAlert, Users, UserRoundCheck,
} from "lucide-react"

const sections = [
  { href: "/admin/students", title: "Students", detail: "Admissions, profiles, and Hifz mentor assignment", icon: Users },
  { href: "/admin/staff", title: "Mentors and staff", detail: "Manage staff and Hifz classes", icon: UserRoundCheck },
  { href: "/admin/setup/academic-years", title: "Hifz years", detail: "Choose the active reporting year", icon: CalendarDays },
  { href: "/admin/academics", title: "Hifz sessions", detail: "Set up daily Hifz sessions", icon: BookOpen },
  { href: "/admin/hifz/attendance", title: "Hifz attendance", detail: "Review session attendance", icon: ClipboardCheck },
  { href: "/admin/hifz/tracking", title: "Hifz recording", detail: "Track new lessons and revision", icon: GraduationCap },
  { href: "/admin/hifz/monthly-report", title: "Monthly reports", detail: "Review and export Hifz progress", icon: FileText },
  { href: "/admin/hifz/exams", title: "Hifz exams", detail: "Configure assessments and marks", icon: BookOpen },
  { href: "/admin/disciplinary", title: "Discipline", detail: "Record and review incidents", icon: ShieldAlert },
  { href: "/admin/chat", title: "Staff chat", detail: "Coordinate with mentors", icon: MessageCircle },
]

export default function AdminPage() {
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <header>
        <p className="text-sm font-semibold uppercase tracking-wide text-teal-700">Administration</p>
        <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">Hifz Management</h1>
        <p className="mt-2 text-slate-600 dark:text-slate-300">Students, mentors, attendance, lessons, revision, and reports.</p>
      </header>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {sections.map(({ href, title, detail, icon: Icon }) => (
          <Link key={href} href={href} className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-teal-400 hover:shadow-md dark:border-slate-700 dark:bg-slate-900">
            <span className="mb-4 inline-flex rounded-xl bg-teal-50 p-3 text-teal-700 dark:bg-teal-950 dark:text-teal-300"><Icon className="h-6 w-6" /></span>
            <h2 className="font-semibold text-slate-900 dark:text-white">{title}</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{detail}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
