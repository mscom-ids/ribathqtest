"use client"

import { AdminSidebar } from "@/components/admin/sidebar"
import { TopNav } from "@/components/admin/top-nav"
import { AdminBackgroundWarmup } from "@/components/admin/admin-background-warmup"
import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    const [sidebarOpen, setSidebarOpen] = useState(false)
    const [isCollapsed, setIsCollapsed] = useState(false)
    const pathname = usePathname()

    // Close sidebar on navigation (mobile)
    useEffect(() => {
        setSidebarOpen(false)
    }, [pathname])

    const isChatPage = pathname.startsWith('/admin/chat')

    return (
        <div className={cn(`bg-[#f5f8f5] dark:bg-[#111520] transition-colors relative`, isChatPage ? "h-screen overflow-hidden" : "min-h-screen")}>
            <AdminBackgroundWarmup />
            <AdminSidebar 
                mobileOpen={sidebarOpen} 
                onClose={() => setSidebarOpen(false)} 
                isCollapsed={isCollapsed}
                onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
            />
            <div className={cn(
                "flex flex-col transition-all duration-300",
                isChatPage ? "h-screen overflow-hidden" : "min-h-screen",
                isCollapsed ? "lg:pl-[80px]" : "lg:pl-[260px]"
            )}>
                <TopNav onOpenSidebar={() => setSidebarOpen(true)} />
                <main className={`flex-1 min-h-0 ${pathname === '/admin' ? 'pt-[76px]' : 'pt-[60px]'} ${isChatPage ? 'h-[calc(100vh-60px)] overflow-hidden flex flex-col' : ''}`}>
                    {isChatPage ? (
                        children
                    ) : (
                        <div className="p-4 sm:p-6 lg:py-7">
                            {children}
                        </div>
                    )}
                </main>
            </div>
        </div>
    )
}
