import quranMap from './quran_map.json';
import { SURAH_LIST } from './data/surah-list'; // Adjust path if needed

// Type Definitions
export type JuzBoundary = {
    id: number;
    start: { surah: number; verse: number };
    end: { surah: number; verse: number };
};

export type HifzLog = {
    id: string;
    student_id: string;
    mode: 'New Verses' | 'Recent Revision' | 'Juz Revision';
    surah_name?: string;
    surah_curr?: number;
    start_v?: number;
    end_v?: number;
    entry_date: string;
    rating?: number;
    juz_number?: number;
    juz_part?: string;
    start_page?: number;
    end_page?: number;
};

// --- CONSTANTS & DATA ---

// Verse counts for all 114 Surahs (Surah 1 to 114)
export const SURAH_VERSE_COUNTS = [
    7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
    123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
    112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
    34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
    54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
    60, 49, 62, 55, 78, 96, 29, 22, 24, 13, 14,
    11, 11, 18, 12, 12, 30, 52, 52, 44, 28,
    28, 20, 56, 40, 31, 50, 40, 46, 42, 29,
    19, 36, 25, 22, 17, 19, 26, 30, 20, 15,
    21, 11, 8, 8, 19, 5, 8, 8, 11, 11,
    8, 3, 9, 5, 4, 7, 3, 6, 3, 5,
    4, 5, 6
];

// Pre-calculate cumulative verse counts for fast global index lookup
const GLOBAL_VERSE_OFFSETS = [0];
for (let i = 0; i < SURAH_VERSE_COUNTS.length; i++) {
    GLOBAL_VERSE_OFFSETS.push(GLOBAL_VERSE_OFFSETS[i] + SURAH_VERSE_COUNTS[i]);
}

// Madani Mushaf page map (mirrors backend/src/utils/quran-data.ts — keep in
// sync if that file changes). Maps each page to its starting Surah/Ayah so
// "pages covered" can be computed from real page boundaries instead of a
// verses-per-page estimate.
const MUSHAF_PAGES = [
    { page: 1, surah: 2, ayah: 1 }, { page: 2, surah: 2, ayah: 6 }, { page: 3, surah: 2, ayah: 17 },
    { page: 4, surah: 2, ayah: 25 }, { page: 5, surah: 2, ayah: 30 }, { page: 6, surah: 2, ayah: 38 },
    { page: 7, surah: 2, ayah: 49 }, { page: 8, surah: 2, ayah: 58 }, { page: 9, surah: 2, ayah: 62 },
    { page: 10, surah: 2, ayah: 70 }, { page: 11, surah: 2, ayah: 77 }, { page: 12, surah: 2, ayah: 84 },
    { page: 13, surah: 2, ayah: 89 }, { page: 14, surah: 2, ayah: 94 }, { page: 15, surah: 2, ayah: 102 },
    { page: 16, surah: 2, ayah: 106 }, { page: 17, surah: 2, ayah: 113 }, { page: 18, surah: 2, ayah: 120 },
    { page: 19, surah: 2, ayah: 127 }, { page: 20, surah: 2, ayah: 135 }, { page: 21, surah: 2, ayah: 142 },
    { page: 22, surah: 2, ayah: 146 }, { page: 23, surah: 2, ayah: 154 }, { page: 24, surah: 2, ayah: 164 },
    { page: 25, surah: 2, ayah: 170 }, { page: 26, surah: 2, ayah: 177 }, { page: 27, surah: 2, ayah: 182 },
    { page: 28, surah: 2, ayah: 187 }, { page: 29, surah: 2, ayah: 191 }, { page: 30, surah: 2, ayah: 197 },
    { page: 31, surah: 2, ayah: 203 }, { page: 32, surah: 2, ayah: 211 }, { page: 33, surah: 2, ayah: 216 },
    { page: 34, surah: 2, ayah: 220 }, { page: 35, surah: 2, ayah: 225 }, { page: 36, surah: 2, ayah: 231 },
    { page: 37, surah: 2, ayah: 234 }, { page: 38, surah: 2, ayah: 238 }, { page: 39, surah: 2, ayah: 246 },
    { page: 40, surah: 2, ayah: 249 }, { page: 41, surah: 2, ayah: 253 }, { page: 42, surah: 2, ayah: 257 },
    { page: 43, surah: 2, ayah: 260 }, { page: 44, surah: 2, ayah: 265 }, { page: 45, surah: 2, ayah: 270 },
    { page: 46, surah: 2, ayah: 275 }, { page: 47, surah: 2, ayah: 282 }, { page: 48, surah: 2, ayah: 283 },
    { page: 49, surah: 3, ayah: 1 }, { page: 50, surah: 3, ayah: 10 }, { page: 51, surah: 3, ayah: 16 },
    { page: 52, surah: 3, ayah: 23 }, { page: 53, surah: 3, ayah: 30 }, { page: 54, surah: 3, ayah: 38 },
    { page: 55, surah: 3, ayah: 46 }, { page: 56, surah: 3, ayah: 53 }, { page: 57, surah: 3, ayah: 62 },
    { page: 58, surah: 3, ayah: 71 }, { page: 59, surah: 3, ayah: 78 }, { page: 60, surah: 3, ayah: 84 },
    { page: 61, surah: 3, ayah: 92 }, { page: 62, surah: 3, ayah: 101 }, { page: 63, surah: 3, ayah: 109 },
    { page: 64, surah: 3, ayah: 116 }, { page: 65, surah: 3, ayah: 122 }, { page: 66, surah: 3, ayah: 133 },
    { page: 67, surah: 3, ayah: 141 }, { page: 68, surah: 3, ayah: 149 }, { page: 69, surah: 3, ayah: 154 },
    { page: 70, surah: 3, ayah: 158 }, { page: 71, surah: 3, ayah: 166 }, { page: 72, surah: 3, ayah: 174 },
    { page: 73, surah: 3, ayah: 181 }, { page: 74, surah: 3, ayah: 187 }, { page: 75, surah: 3, ayah: 195 },
    { page: 76, surah: 4, ayah: 1 }, { page: 77, surah: 4, ayah: 7 }, { page: 78, surah: 4, ayah: 12 },
    { page: 79, surah: 4, ayah: 15 }, { page: 80, surah: 4, ayah: 20 }, { page: 81, surah: 4, ayah: 24 },
    { page: 82, surah: 4, ayah: 27 }, { page: 83, surah: 4, ayah: 34 }, { page: 84, surah: 4, ayah: 38 },
    { page: 85, surah: 4, ayah: 45 }, { page: 86, surah: 4, ayah: 52 }, { page: 87, surah: 4, ayah: 60 },
    { page: 88, surah: 4, ayah: 66 }, { page: 89, surah: 4, ayah: 75 }, { page: 90, surah: 4, ayah: 80 },
    { page: 91, surah: 4, ayah: 87 }, { page: 92, surah: 4, ayah: 92 }, { page: 93, surah: 4, ayah: 95 },
    { page: 94, surah: 4, ayah: 102 }, { page: 95, surah: 4, ayah: 106 }, { page: 96, surah: 4, ayah: 114 },
    { page: 97, surah: 4, ayah: 122 }, { page: 98, surah: 4, ayah: 128 }, { page: 99, surah: 4, ayah: 135 },
    { page: 100, surah: 4, ayah: 141 }, { page: 101, surah: 4, ayah: 148 }, { page: 102, surah: 4, ayah: 155 },
    { page: 103, surah: 4, ayah: 163 }, { page: 104, surah: 4, ayah: 171 }, { page: 105, surah: 4, ayah: 176 },
    { page: 106, surah: 5, ayah: 3 }, { page: 107, surah: 5, ayah: 6 }, { page: 108, surah: 5, ayah: 10 },
    { page: 109, surah: 5, ayah: 14 }, { page: 110, surah: 5, ayah: 18 }, { page: 111, surah: 5, ayah: 24 },
    { page: 112, surah: 5, ayah: 32 }, { page: 113, surah: 5, ayah: 37 }, { page: 114, surah: 5, ayah: 42 },
    { page: 115, surah: 5, ayah: 46 }, { page: 116, surah: 5, ayah: 51 }, { page: 117, surah: 5, ayah: 58 },
    { page: 118, surah: 5, ayah: 65 }, { page: 119, surah: 5, ayah: 71 }, { page: 120, surah: 5, ayah: 77 },
    { page: 121, surah: 5, ayah: 83 }, { page: 122, surah: 5, ayah: 90 }, { page: 123, surah: 5, ayah: 96 },
    { page: 124, surah: 5, ayah: 104 }, { page: 125, surah: 5, ayah: 109 }, { page: 126, surah: 5, ayah: 114 },
    { page: 127, surah: 6, ayah: 1 }, { page: 128, surah: 6, ayah: 9 }, { page: 129, surah: 6, ayah: 19 },
    { page: 130, surah: 6, ayah: 28 }, { page: 131, surah: 6, ayah: 36 }, { page: 132, surah: 6, ayah: 45 },
    { page: 133, surah: 6, ayah: 53 }, { page: 134, surah: 6, ayah: 60 }, { page: 135, surah: 6, ayah: 69 },
    { page: 136, surah: 6, ayah: 74 }, { page: 137, surah: 6, ayah: 82 }, { page: 138, surah: 6, ayah: 91 },
    { page: 139, surah: 6, ayah: 95 }, { page: 140, surah: 6, ayah: 102 }, { page: 141, surah: 6, ayah: 111 },
    { page: 142, surah: 6, ayah: 119 }, { page: 143, surah: 6, ayah: 125 }, { page: 144, surah: 6, ayah: 132 },
    { page: 145, surah: 6, ayah: 138 }, { page: 146, surah: 6, ayah: 143 }, { page: 147, surah: 6, ayah: 147 },
    { page: 148, surah: 6, ayah: 152 }, { page: 149, surah: 6, ayah: 158 }, { page: 150, surah: 7, ayah: 1 },
    { page: 151, surah: 7, ayah: 12 }, { page: 152, surah: 7, ayah: 23 }, { page: 153, surah: 7, ayah: 31 },
    { page: 154, surah: 7, ayah: 38 }, { page: 155, surah: 7, ayah: 44 }, { page: 156, surah: 7, ayah: 52 },
    { page: 157, surah: 7, ayah: 58 }, { page: 158, surah: 7, ayah: 68 }, { page: 159, surah: 7, ayah: 74 },
    { page: 160, surah: 7, ayah: 82 }, { page: 161, surah: 7, ayah: 88 }, { page: 162, surah: 7, ayah: 96 },
    { page: 163, surah: 7, ayah: 105 }, { page: 164, surah: 7, ayah: 121 }, { page: 165, surah: 7, ayah: 131 },
    { page: 166, surah: 7, ayah: 138 }, { page: 167, surah: 7, ayah: 144 }, { page: 168, surah: 7, ayah: 150 },
    { page: 169, surah: 7, ayah: 156 }, { page: 170, surah: 7, ayah: 160 }, { page: 171, surah: 7, ayah: 164 },
    { page: 172, surah: 7, ayah: 171 }, { page: 173, surah: 7, ayah: 179 }, { page: 174, surah: 7, ayah: 188 },
    { page: 175, surah: 7, ayah: 196 }, { page: 176, surah: 8, ayah: 1 }, { page: 177, surah: 8, ayah: 9 },
    { page: 178, surah: 8, ayah: 17 }, { page: 179, surah: 8, ayah: 26 }, { page: 180, surah: 8, ayah: 34 },
    { page: 181, surah: 8, ayah: 41 }, { page: 182, surah: 8, ayah: 46 }, { page: 183, surah: 8, ayah: 53 },
    { page: 184, surah: 8, ayah: 62 }, { page: 185, surah: 8, ayah: 70 }, { page: 186, surah: 9, ayah: 1 },
    { page: 187, surah: 9, ayah: 7 }, { page: 188, surah: 9, ayah: 14 }, { page: 189, surah: 9, ayah: 21 },
    { page: 190, surah: 9, ayah: 27 }, { page: 191, surah: 9, ayah: 32 }, { page: 192, surah: 9, ayah: 37 },
    { page: 193, surah: 9, ayah: 41 }, { page: 194, surah: 9, ayah: 48 }, { page: 195, surah: 9, ayah: 55 },
    { page: 196, surah: 9, ayah: 62 }, { page: 197, surah: 9, ayah: 69 }, { page: 198, surah: 9, ayah: 73 },
    { page: 199, surah: 9, ayah: 80 }, { page: 200, surah: 9, ayah: 87 }, { page: 201, surah: 9, ayah: 94 },
    { page: 202, surah: 9, ayah: 100 }, { page: 203, surah: 9, ayah: 107 }, { page: 204, surah: 9, ayah: 112 },
    { page: 205, surah: 9, ayah: 118 }, { page: 206, surah: 9, ayah: 123 }, { page: 207, surah: 10, ayah: 1 },
    { page: 208, surah: 10, ayah: 7 }, { page: 209, surah: 10, ayah: 15 }, { page: 210, surah: 10, ayah: 21 },
    { page: 211, surah: 10, ayah: 26 }, { page: 212, surah: 10, ayah: 34 }, { page: 213, surah: 10, ayah: 43 },
    { page: 214, surah: 10, ayah: 54 }, { page: 215, surah: 10, ayah: 62 }, { page: 216, surah: 10, ayah: 71 },
    { page: 217, surah: 10, ayah: 79 }, { page: 218, surah: 10, ayah: 89 }, { page: 219, surah: 10, ayah: 98 },
    { page: 220, surah: 10, ayah: 107 }, { page: 221, surah: 11, ayah: 6 }, { page: 222, surah: 11, ayah: 13 },
    { page: 223, surah: 11, ayah: 20 }, { page: 224, surah: 11, ayah: 29 }, { page: 225, surah: 11, ayah: 38 },
    { page: 226, surah: 11, ayah: 46 }, { page: 227, surah: 11, ayah: 54 }, { page: 228, surah: 11, ayah: 63 },
    { page: 229, surah: 11, ayah: 72 }, { page: 230, surah: 11, ayah: 82 }, { page: 231, surah: 11, ayah: 89 },
    { page: 232, surah: 11, ayah: 98 }, { page: 233, surah: 11, ayah: 109 }, { page: 234, surah: 11, ayah: 118 },
    { page: 235, surah: 12, ayah: 5 }, { page: 236, surah: 12, ayah: 15 }, { page: 237, surah: 12, ayah: 23 },
    { page: 238, surah: 12, ayah: 31 }, { page: 239, surah: 12, ayah: 38 }, { page: 240, surah: 12, ayah: 44 },
    { page: 241, surah: 12, ayah: 53 }, { page: 242, surah: 12, ayah: 64 }, { page: 243, surah: 12, ayah: 70 },
    { page: 244, surah: 12, ayah: 79 }, { page: 245, surah: 12, ayah: 87 }, { page: 246, surah: 12, ayah: 96 },
    { page: 247, surah: 12, ayah: 104 }, { page: 248, surah: 13, ayah: 1 }, { page: 249, surah: 13, ayah: 6 },
    { page: 250, surah: 13, ayah: 14 }, { page: 251, surah: 13, ayah: 19 }, { page: 252, surah: 13, ayah: 29 },
    { page: 253, surah: 13, ayah: 35 }, { page: 254, surah: 13, ayah: 43 }, { page: 255, surah: 14, ayah: 6 },
    { page: 256, surah: 14, ayah: 11 }, { page: 257, surah: 14, ayah: 19 }, { page: 258, surah: 14, ayah: 25 },
    { page: 259, surah: 14, ayah: 34 }, { page: 260, surah: 14, ayah: 43 }, { page: 261, surah: 15, ayah: 1 },
    { page: 262, surah: 15, ayah: 16 }, { page: 263, surah: 15, ayah: 32 }, { page: 264, surah: 15, ayah: 52 },
    { page: 265, surah: 15, ayah: 71 }, { page: 266, surah: 15, ayah: 91 }, { page: 267, surah: 16, ayah: 7 },
    { page: 268, surah: 16, ayah: 15 }, { page: 269, surah: 16, ayah: 27 }, { page: 270, surah: 16, ayah: 35 },
    { page: 271, surah: 16, ayah: 43 }, { page: 272, surah: 16, ayah: 55 }, { page: 273, surah: 16, ayah: 65 },
    { page: 274, surah: 16, ayah: 73 }, { page: 275, surah: 16, ayah: 80 }, { page: 276, surah: 16, ayah: 88 },
    { page: 277, surah: 16, ayah: 94 }, { page: 278, surah: 16, ayah: 103 }, { page: 279, surah: 16, ayah: 111 },
    { page: 280, surah: 16, ayah: 119 }, { page: 281, surah: 17, ayah: 1 }, { page: 282, surah: 17, ayah: 8 },
    { page: 283, surah: 17, ayah: 18 }, { page: 284, surah: 17, ayah: 28 }, { page: 285, surah: 17, ayah: 39 },
    { page: 286, surah: 17, ayah: 50 }, { page: 287, surah: 17, ayah: 59 }, { page: 288, surah: 17, ayah: 67 },
    { page: 289, surah: 17, ayah: 76 }, { page: 290, surah: 17, ayah: 87 }, { page: 291, surah: 17, ayah: 97 },
    { page: 292, surah: 17, ayah: 105 }, { page: 293, surah: 18, ayah: 5 }, { page: 294, surah: 18, ayah: 16 },
    { page: 295, surah: 18, ayah: 21 }, { page: 296, surah: 18, ayah: 28 }, { page: 297, surah: 18, ayah: 35 },
    { page: 298, surah: 18, ayah: 46 }, { page: 299, surah: 18, ayah: 54 }, { page: 300, surah: 18, ayah: 62 },
    { page: 301, surah: 18, ayah: 75 }, { page: 302, surah: 18, ayah: 84 }, { page: 303, surah: 18, ayah: 98 },
    { page: 304, surah: 19, ayah: 1 }, { page: 305, surah: 19, ayah: 12 }, { page: 306, surah: 19, ayah: 26 },
    { page: 307, surah: 19, ayah: 39 }, { page: 308, surah: 19, ayah: 52 }, { page: 309, surah: 19, ayah: 65 },
    { page: 310, surah: 19, ayah: 77 }, { page: 311, surah: 19, ayah: 96 }, { page: 312, surah: 20, ayah: 13 },
    { page: 313, surah: 20, ayah: 38 }, { page: 314, surah: 20, ayah: 52 }, { page: 315, surah: 20, ayah: 65 },
    { page: 316, surah: 20, ayah: 77 }, { page: 317, surah: 20, ayah: 88 }, { page: 318, surah: 20, ayah: 99 },
    { page: 319, surah: 20, ayah: 114 }, { page: 320, surah: 20, ayah: 126 }, { page: 321, surah: 21, ayah: 1 },
    { page: 322, surah: 21, ayah: 11 }, { page: 323, surah: 21, ayah: 25 }, { page: 324, surah: 21, ayah: 36 },
    { page: 325, surah: 21, ayah: 45 }, { page: 326, surah: 21, ayah: 58 }, { page: 327, surah: 21, ayah: 73 },
    { page: 328, surah: 21, ayah: 82 }, { page: 329, surah: 21, ayah: 91 }, { page: 330, surah: 21, ayah: 102 },
    { page: 331, surah: 22, ayah: 1 }, { page: 332, surah: 22, ayah: 6 }, { page: 333, surah: 22, ayah: 16 },
    { page: 334, surah: 22, ayah: 24 }, { page: 335, surah: 22, ayah: 31 }, { page: 336, surah: 22, ayah: 39 },
    { page: 337, surah: 22, ayah: 47 }, { page: 338, surah: 22, ayah: 56 }, { page: 339, surah: 22, ayah: 65 },
    { page: 340, surah: 22, ayah: 73 }, { page: 341, surah: 23, ayah: 1 }, { page: 342, surah: 23, ayah: 18 },
    { page: 343, surah: 23, ayah: 28 }, { page: 344, surah: 23, ayah: 43 }, { page: 345, surah: 23, ayah: 60 },
    { page: 346, surah: 23, ayah: 75 }, { page: 347, surah: 23, ayah: 90 }, { page: 348, surah: 23, ayah: 105 },
    { page: 349, surah: 24, ayah: 1 }, { page: 350, surah: 24, ayah: 11 }, { page: 351, surah: 24, ayah: 21 },
    { page: 352, surah: 24, ayah: 28 }, { page: 353, surah: 24, ayah: 32 }, { page: 354, surah: 24, ayah: 37 },
    { page: 355, surah: 24, ayah: 44 }, { page: 356, surah: 24, ayah: 54 }, { page: 357, surah: 24, ayah: 59 },
    { page: 358, surah: 24, ayah: 62 }, { page: 359, surah: 25, ayah: 3 }, { page: 360, surah: 25, ayah: 12 },
    { page: 361, surah: 25, ayah: 21 }, { page: 362, surah: 25, ayah: 33 }, { page: 363, surah: 25, ayah: 44 },
    { page: 364, surah: 25, ayah: 56 }, { page: 365, surah: 25, ayah: 68 }, { page: 366, surah: 26, ayah: 1 },
    { page: 367, surah: 26, ayah: 20 }, { page: 368, surah: 26, ayah: 40 }, { page: 369, surah: 26, ayah: 61 },
    { page: 370, surah: 26, ayah: 84 }, { page: 371, surah: 26, ayah: 112 }, { page: 372, surah: 26, ayah: 137 },
    { page: 373, surah: 26, ayah: 160 }, { page: 374, surah: 26, ayah: 184 }, { page: 375, surah: 26, ayah: 207 },
    { page: 376, surah: 27, ayah: 1 }, { page: 377, surah: 27, ayah: 14 }, { page: 378, surah: 27, ayah: 23 },
    { page: 379, surah: 27, ayah: 36 }, { page: 380, surah: 27, ayah: 45 }, { page: 381, surah: 27, ayah: 56 },
    { page: 382, surah: 27, ayah: 64 }, { page: 383, surah: 27, ayah: 77 }, { page: 384, surah: 27, ayah: 89 },
    { page: 385, surah: 28, ayah: 6 }, { page: 386, surah: 28, ayah: 14 }, { page: 387, surah: 28, ayah: 22 },
    { page: 388, surah: 28, ayah: 29 }, { page: 389, surah: 28, ayah: 36 }, { page: 390, surah: 28, ayah: 44 },
    { page: 391, surah: 28, ayah: 51 }, { page: 392, surah: 28, ayah: 60 }, { page: 393, surah: 28, ayah: 71 },
    { page: 394, surah: 28, ayah: 78 }, { page: 395, surah: 28, ayah: 85 }, { page: 396, surah: 29, ayah: 7 },
    { page: 397, surah: 29, ayah: 15 }, { page: 398, surah: 29, ayah: 24 }, { page: 399, surah: 29, ayah: 31 },
    { page: 400, surah: 29, ayah: 39 }, { page: 401, surah: 29, ayah: 46 }, { page: 402, surah: 29, ayah: 53 },
    { page: 403, surah: 29, ayah: 64 }, { page: 404, surah: 30, ayah: 6 }, { page: 405, surah: 30, ayah: 16 },
    { page: 406, surah: 30, ayah: 25 }, { page: 407, surah: 30, ayah: 33 }, { page: 408, surah: 30, ayah: 42 },
    { page: 409, surah: 30, ayah: 51 }, { page: 410, surah: 31, ayah: 1 }, { page: 411, surah: 31, ayah: 12 },
    { page: 412, surah: 31, ayah: 20 }, { page: 413, surah: 31, ayah: 29 }, { page: 414, surah: 32, ayah: 1 },
    { page: 415, surah: 32, ayah: 12 }, { page: 416, surah: 32, ayah: 21 }, { page: 417, surah: 33, ayah: 1 },
    { page: 418, surah: 33, ayah: 7 }, { page: 419, surah: 33, ayah: 16 }, { page: 420, surah: 33, ayah: 23 },
    { page: 421, surah: 33, ayah: 31 }, { page: 422, surah: 33, ayah: 36 }, { page: 423, surah: 33, ayah: 44 },
    { page: 424, surah: 33, ayah: 51 }, { page: 425, surah: 33, ayah: 55 }, { page: 426, surah: 33, ayah: 63 },
    { page: 427, surah: 34, ayah: 1 }, { page: 428, surah: 34, ayah: 8 }, { page: 429, surah: 34, ayah: 15 },
    { page: 430, surah: 34, ayah: 23 }, { page: 431, surah: 34, ayah: 32 }, { page: 432, surah: 34, ayah: 40 },
    { page: 433, surah: 34, ayah: 49 }, { page: 434, surah: 35, ayah: 4 }, { page: 435, surah: 35, ayah: 12 },
    { page: 436, surah: 35, ayah: 19 }, { page: 437, surah: 35, ayah: 31 }, { page: 438, surah: 35, ayah: 39 },
    { page: 439, surah: 35, ayah: 45 }, { page: 440, surah: 36, ayah: 13 }, { page: 441, surah: 36, ayah: 28 },
    { page: 442, surah: 36, ayah: 41 }, { page: 443, surah: 36, ayah: 55 }, { page: 444, surah: 36, ayah: 71 },
    { page: 445, surah: 37, ayah: 1 }, { page: 446, surah: 37, ayah: 25 }, { page: 447, surah: 37, ayah: 52 },
    { page: 448, surah: 37, ayah: 77 }, { page: 449, surah: 37, ayah: 103 }, { page: 450, surah: 37, ayah: 127 },
    { page: 451, surah: 37, ayah: 154 }, { page: 452, surah: 38, ayah: 1 }, { page: 453, surah: 38, ayah: 17 },
    { page: 454, surah: 38, ayah: 27 }, { page: 455, surah: 38, ayah: 43 }, { page: 456, surah: 38, ayah: 62 },
    { page: 457, surah: 38, ayah: 84 }, { page: 458, surah: 39, ayah: 6 }, { page: 459, surah: 39, ayah: 11 },
    { page: 460, surah: 39, ayah: 22 }, { page: 461, surah: 39, ayah: 32 }, { page: 462, surah: 39, ayah: 41 },
    { page: 463, surah: 39, ayah: 48 }, { page: 464, surah: 39, ayah: 57 }, { page: 465, surah: 39, ayah: 68 },
    { page: 466, surah: 39, ayah: 75 }, { page: 467, surah: 40, ayah: 8 }, { page: 468, surah: 40, ayah: 17 },
    { page: 469, surah: 40, ayah: 26 }, { page: 470, surah: 40, ayah: 34 }, { page: 471, surah: 40, ayah: 41 },
    { page: 472, surah: 40, ayah: 50 }, { page: 473, surah: 40, ayah: 59 }, { page: 474, surah: 40, ayah: 67 },
    { page: 475, surah: 40, ayah: 78 }, { page: 476, surah: 41, ayah: 1 }, { page: 477, surah: 41, ayah: 12 },
    { page: 478, surah: 41, ayah: 21 }, { page: 479, surah: 41, ayah: 30 }, { page: 480, surah: 41, ayah: 39 },
    { page: 481, surah: 41, ayah: 47 }, { page: 482, surah: 42, ayah: 1 }, { page: 483, surah: 42, ayah: 11 },
    { page: 484, surah: 42, ayah: 16 }, { page: 485, surah: 42, ayah: 23 }, { page: 486, surah: 42, ayah: 32 },
    { page: 487, surah: 42, ayah: 45 }, { page: 488, surah: 42, ayah: 52 }, { page: 489, surah: 43, ayah: 11 },
    { page: 490, surah: 43, ayah: 23 }, { page: 491, surah: 43, ayah: 34 }, { page: 492, surah: 43, ayah: 48 },
    { page: 493, surah: 43, ayah: 61 }, { page: 494, surah: 43, ayah: 74 }, { page: 495, surah: 44, ayah: 1 },
    { page: 496, surah: 44, ayah: 19 }, { page: 497, surah: 44, ayah: 40 }, { page: 498, surah: 45, ayah: 1 },
    { page: 499, surah: 45, ayah: 14 }, { page: 500, surah: 45, ayah: 23 }, { page: 501, surah: 45, ayah: 33 },
    { page: 502, surah: 46, ayah: 6 }, { page: 503, surah: 46, ayah: 15 }, { page: 504, surah: 46, ayah: 21 },
    { page: 505, surah: 46, ayah: 29 }, { page: 506, surah: 47, ayah: 1 }, { page: 507, surah: 47, ayah: 12 },
    { page: 508, surah: 47, ayah: 20 }, { page: 509, surah: 47, ayah: 30 }, { page: 510, surah: 48, ayah: 1 },
    { page: 511, surah: 48, ayah: 10 }, { page: 512, surah: 48, ayah: 16 }, { page: 513, surah: 48, ayah: 24 },
    { page: 514, surah: 48, ayah: 29 }, { page: 515, surah: 49, ayah: 5 }, { page: 516, surah: 49, ayah: 12 },
    { page: 517, surah: 50, ayah: 1 }, { page: 518, surah: 50, ayah: 16 }, { page: 519, surah: 50, ayah: 36 },
    { page: 520, surah: 51, ayah: 7 }, { page: 521, surah: 51, ayah: 31 }, { page: 522, surah: 51, ayah: 52 },
    { page: 523, surah: 52, ayah: 15 }, { page: 524, surah: 52, ayah: 32 }, { page: 525, surah: 53, ayah: 1 },
    { page: 526, surah: 53, ayah: 27 }, { page: 527, surah: 53, ayah: 45 }, { page: 528, surah: 54, ayah: 7 },
    { page: 529, surah: 54, ayah: 28 }, { page: 530, surah: 54, ayah: 50 }, { page: 531, surah: 55, ayah: 17 },
    { page: 532, surah: 55, ayah: 41 }, { page: 533, surah: 55, ayah: 68 }, { page: 534, surah: 56, ayah: 17 },
    { page: 535, surah: 56, ayah: 51 }, { page: 536, surah: 56, ayah: 77 }, { page: 537, surah: 57, ayah: 4 },
    { page: 538, surah: 57, ayah: 12 }, { page: 539, surah: 57, ayah: 19 }, { page: 540, surah: 57, ayah: 25 },
    { page: 541, surah: 58, ayah: 1 }, { page: 542, surah: 58, ayah: 7 }, { page: 543, surah: 58, ayah: 12 },
    { page: 544, surah: 58, ayah: 22 }, { page: 545, surah: 59, ayah: 4 }, { page: 546, surah: 59, ayah: 10 },
    { page: 547, surah: 59, ayah: 17 }, { page: 548, surah: 60, ayah: 1 }, { page: 549, surah: 60, ayah: 6 },
    { page: 550, surah: 60, ayah: 12 }, { page: 551, surah: 61, ayah: 6 }, { page: 552, surah: 62, ayah: 1 },
    { page: 553, surah: 62, ayah: 9 }, { page: 554, surah: 63, ayah: 5 }, { page: 555, surah: 64, ayah: 1 },
    { page: 556, surah: 64, ayah: 10 }, { page: 557, surah: 65, ayah: 1 }, { page: 558, surah: 65, ayah: 6 },
    { page: 559, surah: 66, ayah: 1 }, { page: 560, surah: 66, ayah: 8 }, { page: 561, surah: 67, ayah: 1 },
    { page: 562, surah: 67, ayah: 13 }, { page: 563, surah: 67, ayah: 27 }, { page: 564, surah: 68, ayah: 16 },
    { page: 565, surah: 68, ayah: 43 }, { page: 566, surah: 69, ayah: 9 }, { page: 567, surah: 69, ayah: 35 },
    { page: 568, surah: 70, ayah: 11 }, { page: 569, surah: 70, ayah: 40 }, { page: 570, surah: 71, ayah: 11 },
    { page: 571, surah: 72, ayah: 1 }, { page: 572, surah: 72, ayah: 14 }, { page: 573, surah: 73, ayah: 1 },
    { page: 574, surah: 73, ayah: 20 }, { page: 575, surah: 74, ayah: 18 }, { page: 576, surah: 74, ayah: 48 },
    { page: 577, surah: 75, ayah: 20 }, { page: 578, surah: 76, ayah: 6 }, { page: 579, surah: 76, ayah: 26 },
    { page: 580, surah: 77, ayah: 20 }, { page: 581, surah: 78, ayah: 1 }, { page: 582, surah: 78, ayah: 31 },
    { page: 583, surah: 79, ayah: 16 }, { page: 584, surah: 80, ayah: 1 }, { page: 585, surah: 81, ayah: 1 },
    { page: 586, surah: 82, ayah: 1 }, { page: 587, surah: 83, ayah: 7 }, { page: 588, surah: 83, ayah: 35 },
    { page: 589, surah: 85, ayah: 1 }, { page: 590, surah: 86, ayah: 1 }, { page: 591, surah: 87, ayah: 16 },
    { page: 592, surah: 89, ayah: 1 }, { page: 593, surah: 89, ayah: 24 }, { page: 594, surah: 91, ayah: 1 },
    { page: 595, surah: 92, ayah: 15 }, { page: 596, surah: 95, ayah: 1 }, { page: 597, surah: 97, ayah: 1 },
    { page: 598, surah: 98, ayah: 8 }, { page: 599, surah: 100, ayah: 10 }, { page: 600, surah: 103, ayah: 1 },
    { page: 601, surah: 106, ayah: 1 }, { page: 602, surah: 109, ayah: 1 }, { page: 603, surah: 112, ayah: 1 },
];

// --- HELPER FUNCTIONS ---

export function getSurahId(name: string): number {
    if (!name) return 0;

    // 1. Try exact match from SURAH_LIST
    const found = SURAH_LIST.find(s => s.name.toLowerCase() === name.toLowerCase());
    if (found) return found.id;

    // 2. Try partial match
    // e.g. "Ar-Ra'd" vs "Ar-Rad" or "Al-Fatiha" vs "Al-Fatihah"
    const partial = SURAH_LIST.find(s =>
        s.name.toLowerCase().includes(name.toLowerCase()) ||
        name.toLowerCase().includes(s.name.toLowerCase())
    );
    if (partial) return partial.id;

    // 3. Fallback: Parse number if name is just a string "1", "2"
    const num = parseInt(name);
    if (!isNaN(num) && num >= 1 && num <= 114) return num;

    return 0;
}

export function toGlobalVerseIndex(surah: number, verse: number): number {
    if (surah < 1 || surah > 114) return -1;
    return GLOBAL_VERSE_OFFSETS[surah - 1] + verse;
}

/**
 * Counts the number of mushaf pages a set of "New Verses" logs actually covers,
 * by merging overlapping/adjacent verse ranges and checking mushaf page boundaries.
 *
 * This is the SAME algorithm the backend's `calculateCoveredPagesFromLogs` uses,
 * so any UI showing "pages" from logs must call this (not a verse-count/15 heuristic)
 * to stay consistent with backend-computed totals.
 *
 * Callers should pre-filter logs to `mode === 'New Verses'` — the function itself
 * does not filter by mode.
 */
export function calculateCoveredPagesFromLogs(
    logs: { surah_name?: string | null; start_v?: number | null; end_v?: number | null; start_page?: number | null; end_page?: number | null }[]
): number {
    let fallbackPages = 0;
    const ranges: { start: number; end: number }[] = [];

    for (const log of logs) {
        const surahId = getSurahId(log.surah_name || "");
        if (surahId && log.start_v && log.end_v) {
            const startGlobal = toGlobalVerseIndex(surahId, log.start_v);
            const endGlobal = toGlobalVerseIndex(surahId, log.end_v);
            if (startGlobal >= 0 && endGlobal >= 0) {
                ranges.push({
                    start: Math.min(startGlobal, endGlobal),
                    end: Math.max(startGlobal, endGlobal),
                });
            }
            continue;
        }
        if (log.start_page && log.end_page) {
            fallbackPages += Math.max((log.end_page - log.start_page) + 1, 0);
        }
    }

    if (ranges.length === 0) return fallbackPages;

    ranges.sort((a, b) => a.start - b.start);
    const merged = [ranges[0]];
    for (let i = 1; i < ranges.length; i++) {
        const current = merged[merged.length - 1];
        const next = ranges[i];
        if (next.start <= current.end + 1) {
            if (next.end > current.end) current.end = next.end;
        } else {
            merged.push({ ...next });
        }
    }

    let coveredPages = fallbackPages;
    for (let i = 0; i < MUSHAF_PAGES.length; i++) {
        const pageStart = MUSHAF_PAGES[i];
        const startGlobal = toGlobalVerseIndex(pageStart.surah, pageStart.ayah);
        const endGlobal = i + 1 < MUSHAF_PAGES.length
            ? toGlobalVerseIndex(MUSHAF_PAGES[i + 1].surah, MUSHAF_PAGES[i + 1].ayah) - 1
            : toGlobalVerseIndex(114, 6);

        for (const range of merged) {
            if (range.start <= endGlobal && range.end >= endGlobal) {
                coveredPages++;
                break;
            }
        }
    }

    return coveredPages;
}

// --- CORE LOGIC ---

/**
 * Calculates which Juz are fully completed by the student.
 * Returns an array of completed Juz IDs (e.g., [1, 2, 21, 30])
 */
export function getCompletedJuzList(logs: HifzLog[]): number[] {
    // 1. Convert all "New Verses" logs into Global Ranges
    const ranges: { start: number; end: number }[] = [];

    logs.forEach(log => {
        if (log.mode !== 'New Verses' || !log.surah_name || !log.start_v || !log.end_v) return;

        const surahId = getSurahId(log.surah_name);
        if (!surahId) return;

        // Verify validity of start/end
        const startGlobal = toGlobalVerseIndex(surahId, log.start_v);
        const endGlobal = toGlobalVerseIndex(surahId, log.end_v);

        if (startGlobal !== -1 && endGlobal !== -1 && endGlobal >= startGlobal) {
            ranges.push({ start: startGlobal, end: endGlobal });
        }
    });

    if (ranges.length === 0) return [];

    // 2. Merge overlapping ranges
    ranges.sort((a, b) => a.start - b.start);

    const merged: { start: number; end: number }[] = [];
    let current = ranges[0];

    for (let i = 1; i < ranges.length; i++) {
        const next = ranges[i];
        // If overlap or adjacent (next.start <= current.end + 1)
        if (next.start <= current.end + 1) {
            current.end = Math.max(current.end, next.end);
        } else {
            merged.push(current);
            current = next;
        }
    }
    merged.push(current);

    // 3. Check each Juz against merged ranges
    const completedJuz: number[] = [];
    const juzMap = quranMap as JuzBoundary[];

    juzMap.forEach(juz => {
        const juzStartGlobal = toGlobalVerseIndex(juz.start.surah, juz.start.verse);
        const juzEndGlobal = toGlobalVerseIndex(juz.end.surah, juz.end.verse);

        // Check if any single merged range fully covers this Juz
        // (A Juz must be contiguous to be counted as "complete" in this logic)
        const isCovered = merged.some(range =>
            range.start <= juzStartGlobal && range.end >= juzEndGlobal
        );

        if (isCovered) {
            completedJuz.push(juz.id);
        }
    });

    return completedJuz;
}

/**
 * Calculates total progress percentage
 */
export function calculateProgress(logs: HifzLog[]): number {
    const completed = getCompletedJuzList(logs);
    return (completed.length / 30) * 100;
}

/**
 * Legacy support / compatibility
 */
export function isJuzCompleted(juzId: number, logs: HifzLog[]): boolean {
    const list = getCompletedJuzList(logs);
    return list.includes(juzId);
}

// --- FORMATTING UTILITIES ---

export const getArabic = (name?: string) => {
    // If not found, look up SURAH_LIST or just return name
    // (Notice: SURAH_LIST does not contain name_arabic, so we rely on fallback)
    
    // Fallback dictionary
    const fallback: Record<string, string> = {
        "Al-Fatiha": "الفاتحة", "Al-Baqarah": "البقرة", "Al-Imran": "آل عمران", "An-Nisa": "النساء",
        "Al-Ma'idah": "المائدة", "Al-An'am": "الأنعام", "Al-A'raf": "الأعراف", "Al-Anfal": "الأنفال",
        "At-Tawbah": "التوبة", "Yunus": "يونس", "Hud": "هود", "Yusuf": "يوسف", "Ar-Ra'd": "الرعد",
        "Ibrahim": "إبراهيم", "Al-Hijr": "الحجر", "An-Nahl": "النحل", "Al-Isra": "الإسراء",
        "Al-Kahf": "الكهف", "Maryam": "مريم", "Ta-Ha": "طه", "Al-Anbiya": "الأنبياء",
        "Al-Hajj": "الحج", "Al-Mu'minun": "المؤمنون", "An-Nur": "النور", "Al-Furqan": "الفرقان",
        "Ash-Shu'ara": "الشعراء", "An-Naml": "النمل", "Al-Qasas": "القصص", "Al-Ankabut": "العنكبوت",
        "Ar-Rum": "الروم", "Luqman": "لقمان", "As-Sajdah": "السجدة", "Al-Ahzab": "الأحزاب",
        "Saba": "سبأ", "Fatir": "فاطر", "Ya-Sin": "يس", "As-Saffat": "الصافات", "Sad": "ص",
        "Az-Zumar": "الزمر", "Ghafir": "غافر", "Fussilat": "فصلت", "Ash-Shura": "الشورى",
        "Az-Zukhruf": "الزخرف", "Ad-Dukhan": "الدخان", "Al-Jathiyah": "الجاثية", "Al-Ahqaf": "الأحقاف",
        "Muhammad": "محمد", "Al-Fath": "الفتح", "Al-Hujurat": "الحجرات", "Qaf": "ق",
        "Ad-Dhariyat": "الذاريات", "At-Tur": "الطور", "An-Najm": "النجم", "Al-Qamar": "القمر",
        "Ar-Rahman": "الرحمن", "Al-Waqi'ah": "الواقعة", "Al-Hadid": "الحديد", "Al-Mujadila": "المجادلة",
        "Al-Hashr": "الحشر", "Al-Mumtahanah": "الممتحنة", "As-Saff": "الصف", "Al-Jumu'ah": "الجمعة",
        "Al-Munafiqun": "المنافقون", "At-Taghabun": "التغابن", "At-Talaq": "الطلاق", "At-Tahrim": "التحريم",
        "Al-Mulk": "الملك", "Al-Qalam": "القلم", "Al-Haqqah": "الحاقة", "Al-Ma'arij": "المعارج",
        "Nuh": "نوح", "Al-Jinn": "الجن", "Al-Muzzammil": "المزمل", "Al-Muddaththir": "المدثر",
        "Al-Qiyamah": "القيامة", "Al-Insan": "الإنسان", "Al-Mursalat": "المرسلات", "An-Naba": "النبأ",
        "An-Nazi'at": "النازعات", "Abasa": "عبس", "At-Takwir": "التكوير", "Al-Infitar": "الانفطار",
        "Al-Mutaffifin": "المطففين", "Al-Inshiqaq": "الانشقاق", "Al-Buruj": "البروج", "At-Tariq": "الطارق",
        "Al-A'la": "الأعلى", "Al-Ghashiyah": "الغاشية", "Al-Fajr": "الفجر", "Al-Balad": "البلد",
        "Ash-Shams": "الشمس", "Al-Layl": "الليل", "Ad-Duha": "الضحى", "Ash-Sharh": "الشرح",
        "At-Tin": "التين", "Al-Alaq": "العلق", "Al-Qadr": "القدر", "Al-Bayyinah": "البينة",
        "Az-Zalzalah": "الزلزلة", "Al-Adiyat": "العاديات", "Al-Qari'ah": "القارعة", "At-Takathur": "التكاثر",
        "Al-Asr": "العصر", "Al-Humazah": "الهمزة", "Al-Fil": "الفيل", "Quraysh": "قريش",
        "Al-Ma'un": "الماعون", "Al-Kawthar": "الكوثر", "Al-Kafirun": "الكافرون", "An-Nasr": "النصر",
        "Al-Masad": "المسد", "Al-Ikhlas": "الإخلاص", "Al-Falaq": "الفلق", "An-Nas": "الناس"
    };
    return name && fallback[name] ? fallback[name] : name || "";
};

export const toArabicNum = (num: number | string | undefined | null) => {
    if (num == null) return "?";
    return num.toString().replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[parseInt(d)]);
};

export function formatHifzLogLabel(log: Partial<HifzLog> | any) {
    if (log.mode?.startsWith("Juz Revision")) {
        const j = toArabicNum(log.juz_number || log.juz);
        const p = log.juz_portion || log.juz_part || "Full";
        
        if (p.toLowerCase() === "full") return `جزء ${j} الخ`;
        
        const qMatch = p.match(/q(\d)/i);
        if (qMatch) return `جزء ${j} ربع ${toArabicNum(qMatch[1])}`;

        const hMatch = p.match(/(\d)(st|nd|rd|th)? half/i);
        if (hMatch) return `جزء ${j} نصف ${toArabicNum(hMatch[1])}`;

        return `جزء ${j} ${p}`; // Fallback
    }

    // New Verses or Recent Revision
    const arabicSurah = getArabic(log.surah_name);
    if (log.start_v && log.end_v) return `${arabicSurah} (${toArabicNum(log.start_v)}–${toArabicNum(log.end_v)})`;
    if (log.start_page && log.end_page) return `${arabicSurah} ص ${toArabicNum(log.start_page)}–${toArabicNum(log.end_page)}`;
    if (log.verses) return `${arabicSurah} (${toArabicNum(log.verses)})`;
    return arabicSurah || "—";
}
