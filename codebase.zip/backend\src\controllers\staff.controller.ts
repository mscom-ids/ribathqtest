import { Request, Response } from 'express';
import { db } from '../config/db';
import {
    ADMINISTRATIVE_STAFF_ROLES,
    LEADERSHIP_STAFF_ROLES,
    TEACHING_STAFF_ROLES,
    getStaffId,
    getDelegationContext,
    isLeadershipStaffRole,
    isAdministrativeStaffRole,
    staffDomainForRole,
    staffRoleLabel,
} from '../utils/staff.utils';
import { supabaseAdmin } from '../config/supabase';
import { getAcademicYearContext } from '../utils/academic-year';
import { cachedResult, invalidateCacheByPrefix, makeCacheKey } from '../utils/server-cache';
import { getActiveMentorStudents } from '../services/mentor-students.service';

const SAFE_STAFF_COLUMNS = `
    id, profile_id, name, role, phone, email, photo_url, address, place,
    phone_contacts, staff_id, is_active, created_at
`;
const STAFF_ROLES = [...TEACHING_STAFF_ROLES, ...LEADERSHIP_STAFF_ROLES, ...ADMINISTRATIVE_STAFF_ROLES];

function invalidateStaffCaches() {
    invalidateCacheByPrefix('staff:');
    invalidateCacheByPrefix('auth:me');
    invalidateCacheByPrefix('academic-placements:attendance-groups');
    invalidateCacheByPrefix('attendance:schedules');
    invalidateCacheByPrefix('mentor-students:');
    invalidateCacheByPrefix('hifz:');
}

export const getMyStaffProfile = async (req: Request, res: Response) => {
    try {
        const user = (req as any).user;
        if (!user) {
            return res.status(401).json({ success: false, error: 'Unauthorized' });
        }
        const staffId = await getStaffId(req);
        if (!staffId) {
            return res.status(404).json({ success: false, error: 'Staff profile not found' });
        }

        const result = await cachedResult(
            makeCacheKey('staff:profile', { id: staffId }),
            5 * 60_000,
            () => db.query(`SELECT ${SAFE_STAFF_COLUMNS} FROM staff WHERE id = $1 LIMIT 1`, [staffId]),
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Staff profile not found' });
        }
        
        res.json({ success: true, staff: result.rows[0], acting_as: !!(req as any).delegation });
    } catch (err) {
        console.error('Error fetching staff profile:', err);
        res.status(500).json({ success: false, error: 'Failed' });
    }
};

export const getStaffStudents = async (req: Request, res: Response) => {
    try {
        const { id: staffId } = req.params;
        if (!staffId) {
            return res.status(400).json({ success: false, error: 'id required' });
        }
        const academicContext = await getAcademicYearContext(db, req.query.academic_year_id);

        const staffResult = await db.query(
            'SELECT id, name, role FROM staff WHERE id = $1 LIMIT 1',
            [staffId]
        );
        if (staffResult.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Staff not found' });
        }

        const [hifzStudents, otherAssignments] = await Promise.all([
            getActiveMentorStudents(db, String(staffId), {
                academicYearId: academicContext.academicYearId,
            }),
            db.query(
                `SELECT s.adm_no AS id, s.adm_no, s.name, s.photo_url, s.standard, s.batch_year,
                        false AS is_hifz,
                        (sys.school_mentor_id = $1) AS is_school,
                        (sys.madrasa_mentor_id = $1) AS is_madrasa
                 FROM students s
                 JOIN student_year_snapshots sys
                   ON sys.student_id = s.adm_no
                  AND sys.academic_year_id = $2
                 WHERE (sys.school_mentor_id = $1 OR sys.madrasa_mentor_id = $1)
                   AND LOWER(COALESCE(s.status, 'active')) = 'active'
                 ORDER BY s.name`,
                [staffId, academicContext.academicYearId],
            ),
        ]);
        const merged = new Map<string, any>();
        for (const student of otherAssignments.rows) merged.set(student.adm_no, student);
        for (const student of hifzStudents) {
            const existing = merged.get(student.adm_no) || {};
            merged.set(student.adm_no, {
                ...existing,
                ...student,
                is_hifz: true,
                is_school: Boolean(existing.is_school),
                is_madrasa: Boolean(existing.is_madrasa),
            });
        }

        res.json({
            success: true,
            students: Array.from(merged.values()).sort((a, b) => a.name.localeCompare(b.name)),
        });
    } catch (err: any) {
        console.error('Error fetching assigned students:', err);
        res.status(500).json({
            success: false,
            error: err.message || 'Failed to fetch assigned students',
        });
    }
};

export const assignStudentsToMentor = async (req: Request, res: Response) => {
    try {
        const { id } = req.params; // staff id
        const { student_ids, section } = req.body;

        if (!student_ids?.length || !section) {
            return res.status(400).json({ success: false, error: 'student_ids and section are required' });
        }

        const fieldMap: Record<string, string> = {
            hifz:    'hifz_mentor_id',
            school:  'school_mentor_id',
            madrasa: 'madrasa_mentor_id',
        };
        const field = fieldMap[section];
        if (!field) return res.status(400).json({ success: false, error: 'Invalid section' });
        const academicContext = await getAcademicYearContext(db, req.body.academic_year_id || req.query.academic_year_id);
        if (!academicContext.academicYearId) {
            return res.status(400).json({ success: false, error: 'Current academic year not found' });
        }

        const client = await db.getClient();
        try {
            await client.query('BEGIN');
            await client.query(
                `INSERT INTO student_year_snapshots (student_id, academic_year_id, ${field}, status, updated_at)
                 SELECT sid, $2::uuid, $3::uuid, 'active', now()
                 FROM unnest($1::text[]) AS sid
                 ON CONFLICT (student_id, academic_year_id) DO UPDATE SET
                    ${field} = EXCLUDED.${field},
                    status = 'active',
                    updated_at = now()`,
                [student_ids, academicContext.academicYearId, id]
            );
            if (academicContext.mode === 'current') {
                await client.query(
                    `UPDATE students SET ${field} = $1 WHERE adm_no = ANY($2::text[])`,
                    [id, student_ids]
                );
            }
            if (section === 'hifz') {
                await client.query(
                    `UPDATE hifz_mentor_history
                     SET assigned_until = CURRENT_DATE
                     WHERE student_id = ANY($1::text[])
                       AND assigned_until IS NULL
                       AND mentor_id IS DISTINCT FROM $2::uuid`,
                    [student_ids, id],
                );
                await client.query(
                    `INSERT INTO hifz_mentor_history (student_id, mentor_id, assigned_from)
                     SELECT sid, $2::uuid, CURRENT_DATE
                     FROM unnest($1::text[]) AS sid
                     WHERE NOT EXISTS (
                         SELECT 1
                         FROM hifz_mentor_history history
                         WHERE history.student_id = sid
                           AND history.mentor_id = $2::uuid
                           AND history.assigned_until IS NULL
                     )`,
                    [student_ids, id],
                );
                await client.query(
                    `INSERT INTO student_hifz_profiles (student_id, mentor_id, active, started_on, updated_at)
                     SELECT sid, $2::uuid, true, CURRENT_DATE, now()
                     FROM unnest($1::text[]) AS sid
                     ON CONFLICT (student_id) DO UPDATE SET
                        mentor_id = EXCLUDED.mentor_id,
                        active = true,
                        updated_at = now()`,
                    [student_ids, id],
                );
            }
            await client.query('COMMIT');
        } catch (txErr) {
            await client.query('ROLLBACK');
            throw txErr;
        } finally {
            client.release();
        }
        invalidateCacheByPrefix('students:');
        invalidateCacheByPrefix('attendance:');
        invalidateCacheByPrefix('reports:');
        invalidateCacheByPrefix('staff:');
        invalidateCacheByPrefix('mentor-students:');
        invalidateCacheByPrefix('hifz:');

        res.json({ success: true });
    } catch (err: any) {
        console.error('assignStudentsToMentor error:', err);
        res.status(500).json({ success: false, error: err.message || 'Failed to assign students' });
    }
};

export const unassignStudentFromMentor = async (req: Request, res: Response) => {
    try {
        const { id } = req.params; // staff id
        const { student_id, section } = req.body;

        const fieldMap: Record<string, string> = {
            hifz:    'hifz_mentor_id',
            school:  'school_mentor_id',
            madrasa: 'madrasa_mentor_id',
        };
        const field = fieldMap[section];
        if (!field) return res.status(400).json({ success: false, error: 'Invalid section' });
        const academicContext = await getAcademicYearContext(db, req.body.academic_year_id || req.query.academic_year_id);
        if (!academicContext.academicYearId) {
            return res.status(400).json({ success: false, error: 'Current academic year not found' });
        }

        const client = await db.getClient();
        try {
            await client.query('BEGIN');
            await client.query(
                `UPDATE student_year_snapshots
                 SET ${field} = NULL, updated_at = now()
                 WHERE student_id = $1
                   AND academic_year_id = $2
                   AND ${field} = $3`,
                [student_id, academicContext.academicYearId, id]
            );
            if (academicContext.mode === 'current') {
                await client.query(
                    `UPDATE students SET ${field} = NULL WHERE adm_no = $1 AND ${field} = $2`,
                    [student_id, id]
                );
            }
            if (section === 'hifz') {
                await client.query(
                    `UPDATE hifz_mentor_history
                     SET assigned_until = CURRENT_DATE
                     WHERE student_id = $1
                       AND mentor_id = $2
                       AND assigned_until IS NULL`,
                    [student_id, id],
                );
                await client.query(
                    `UPDATE student_hifz_profiles
                     SET mentor_id = NULL, active = false, updated_at = now()
                     WHERE student_id = $1 AND mentor_id = $2`,
                    [student_id, id],
                );
            }
            await client.query('COMMIT');
        } catch (txErr) {
            await client.query('ROLLBACK');
            throw txErr;
        } finally {
            client.release();
        }
        invalidateCacheByPrefix('students:');
        invalidateCacheByPrefix('attendance:');
        invalidateCacheByPrefix('reports:');
        invalidateCacheByPrefix('staff:');
        invalidateCacheByPrefix('mentor-students:');
        invalidateCacheByPrefix('hifz:');

        res.json({ success: true });
    } catch (err: any) {
        console.error('unassignStudentFromMentor error:', err);
        res.status(500).json({ success: false, error: err.message || 'Failed to unassign student' });
    }
};

export const getMyAssignedStudents = async (req: Request, res: Response) => {
    try {
        const { staff_id } = req.query;
        if (!staff_id) return res.status(400).json({ success: false, error: 'staff_id required' });
        const academicContext = await getAcademicYearContext(db, req.query.academic_year_id);

        const students = await getActiveMentorStudents(db, String(staff_id), {
            academicYearId: academicContext.academicYearId,
        });

        res.json({ success: true, students });
    } catch (err) {
        console.error('Error fetching assigned students:', err);
        res.status(500).json({ success: false, error: 'Failed' });
    }
};

export const cancelSession = async (req: Request, res: Response) => {
    try {
        const { date, session_id } = req.body;
        
        const existingResult = await db.query('SELECT cancelled_sessions FROM academic_calendar WHERE date = $1', [date]);
        
        if (existingResult.rows.length === 0) {
            const cancelled_sessions = { [session_id]: true };
            await db.query(
                'INSERT INTO academic_calendar (date, is_holiday, cancelled_sessions) VALUES ($1, false, $2)',
                [date, cancelled_sessions]
            );
        } else {
            const currentCancelled = existingResult.rows[0].cancelled_sessions || {};
            currentCancelled[session_id] = true;
            await db.query(
                'UPDATE academic_calendar SET cancelled_sessions = $1 WHERE date = $2',
                [currentCancelled, date]
            );
        }
        
        res.json({ success: true });
    } catch (err) {
        console.error('Error cancelling session:', err);
        res.status(500).json({ success: false, error: 'Failed to cancel session' });
    }
};

export const createStaffLogin = async (req: Request, res: Response) => {
    try {
        const { id } = req.params; // Staff ID
        const { password } = req.body;

        if (!password || String(password).length < 8) {
            return res.status(400).json({ success: false, error: 'Password must be at least 8 characters' });
        }
        
        const bcrypt = require('bcrypt'); // Lazy load
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const client = await db.getClient();
        try {
            await client.query('BEGIN');
            
            // 1. Get staff info
            const staffRes = await client.query('SELECT name, email, role, phone FROM staff WHERE id = $1', [id]);
            if (staffRes.rows.length === 0) throw new Error("Staff not found");

            // Update the staff record with the new password
            await client.query('UPDATE staff SET password_hash = $1 WHERE id = $2', [hashedPassword, id]);

            await client.query('COMMIT');
            res.json({ success: true });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err: any) {
        console.error('Create Login Error:', err);
        res.status(500).json({ success: false, error: err.message });
    }
};

export const archiveStaff = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const client = await db.getClient();
        try {
            await client.query('BEGIN');
            // Unassign students across all specific mentor slots
            await client.query('UPDATE students SET hifz_mentor_id = NULL WHERE hifz_mentor_id = $1', [id]);
            await client.query('UPDATE students SET school_mentor_id = NULL WHERE school_mentor_id = $1', [id]);
            await client.query('UPDATE students SET madrasa_mentor_id = NULL WHERE madrasa_mentor_id = $1', [id]);
            // Archive staff
            await client.query('UPDATE staff SET is_active = false, profile_id = NULL WHERE id = $1', [id]);
            // We should ideally delete the user from `users` but we can leave it or set status=inactive.
            await client.query('COMMIT');
            invalidateStaffCaches();
            res.json({ success: true });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) {
        res.status(500).json({ success: false, error: 'Failed' });
    }
};

export const restoreStaff = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        await db.query('UPDATE staff SET is_active = true WHERE id = $1', [id]);
        invalidateStaffCaches();
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Failed' });
    }
};

export const getAllStaff = async (_req: Request, res: Response) => {
    try {
        const payload = await cachedResult('staff:list', 2 * 60_000, async () => {
            const result = await db.query(
                `WITH responsibility_counts AS (
                    SELECT mentor_id,
                           COUNT(DISTINCT adm_no) AS assigned_students,
                           COUNT(DISTINCT adm_no) FILTER (WHERE responsibility = 'hifz') AS hifz_students,
                           COUNT(DISTINCT adm_no) FILTER (WHERE responsibility = 'school') AS school_students,
                           COUNT(DISTINCT adm_no) FILTER (WHERE responsibility = 'madrasa') AS madrasa_students
                    FROM (
                        SELECT hifz_mentor_id AS mentor_id, adm_no, 'hifz' AS responsibility
                        FROM students
                        WHERE status = 'active' AND hifz_mentor_id IS NOT NULL
                        UNION ALL
                        SELECT school_mentor_id AS mentor_id, adm_no, 'school' AS responsibility
                        FROM students
                        WHERE status = 'active' AND school_mentor_id IS NOT NULL
                        UNION ALL
                        SELECT madrasa_mentor_id AS mentor_id, adm_no, 'madrasa' AS responsibility
                        FROM students
                        WHERE status = 'active' AND madrasa_mentor_id IS NOT NULL
                    ) assigned
                    GROUP BY mentor_id
                )
                SELECT ${SAFE_STAFF_COLUMNS},
                       COALESCE(rc.assigned_students, 0)::int AS assigned_students,
                       COALESCE(rc.hifz_students, 0)::int AS hifz_students,
                       COALESCE(rc.school_students, 0)::int AS school_students,
                       COALESCE(rc.madrasa_students, 0)::int AS madrasa_students,
                       NULL::timestamptz AS last_login
                FROM staff
                LEFT JOIN responsibility_counts rc ON rc.mentor_id = staff.id
                ORDER BY name ASC`,
            );

            const staff = result.rows.map((member: any) => {
                const responsibilities: string[] = [];
                if (Number(member.hifz_students || 0) > 0) responsibilities.push('Hifz Mentor');
                if (Number(member.school_students || 0) > 0) responsibilities.push('School Mentor');
                if (Number(member.madrasa_students || 0) > 0) responsibilities.push('Madrasa Mentor');

                const staff_category = staffDomainForRole(member.role);
                if (responsibilities.length === 0) {
                    if (isLeadershipStaffRole(member.role)) responsibilities.push('Leadership Role');
                    else if (isAdministrativeStaffRole(member.role)) responsibilities.push('System Administration');
                    else responsibilities.push('General Mentor');
                }

                return {
                    ...member,
                    staff_category,
                    role_label: staffRoleLabel(member.role),
                    assigned_responsibilities: responsibilities,
                };
            });

            const stats = staff.reduce((acc: any, member: any) => {
                if (member.is_active === false) {
                    acc.archived_staff += 1;
                    return acc;
                }

                acc.total_staff += 1;
                if (member.staff_category === 'teaching') acc.teaching_staff += 1;
                else acc.leadership_staff += 1;
                if (member.staff_category === 'administrative') acc.admin_staff += 1;
                return acc;
            }, { total_staff: 0, teaching_staff: 0, leadership_staff: 0, admin_staff: 0, archived_staff: 0 });

            return { staff, stats };
        });

        res.json({ success: true, ...payload });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Failed to fetch staff' });
    }
};
export const getStaffById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const payload = await cachedResult(
            makeCacheKey('staff:detail', { id }),
            2 * 60_000,
            async () => {
                const [staffResult, studentCount] = await Promise.all([
                    db.query(`SELECT ${SAFE_STAFF_COLUMNS} FROM staff WHERE id = $1 LIMIT 1`, [id]),
                    db.query(
                        `SELECT COUNT(*) FROM students
                         WHERE (hifz_mentor_id = $1 OR school_mentor_id = $1 OR madrasa_mentor_id = $1)
                           AND status = 'active'`,
                        [id],
                    ),
                ]);
                if (staffResult.rows.length === 0) return null;
                return {
                    staff: staffResult.rows[0],
                    student_count: parseInt(studentCount.rows[0].count, 10),
                };
            },
        );

        if (!payload) return res.status(404).json({ success: false, error: 'Staff not found' });
        res.json({ success: true, ...payload });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Failed to fetch staff member' });
    }
};
export const updateStaffProfile = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const updateData = req.body;
        delete updateData.id; // Safety

        const allowedFields = ['name', 'role', 'phone', 'email', 'photo_url', 'address', 'place', 'phone_contacts', 'staff_id'];
        const setClauses: string[] = [];
        const values: any[] = [];
        let paramCount = 1;

        for (const key of Object.keys(updateData)) {
            if (allowedFields.includes(key)) {
                setClauses.push(`${key} = $${paramCount}`);
                
                let val = updateData[key];
                // pg driver needs JSON arrays to be stringified for JSONB columns
                if (key === 'phone_contacts' && Array.isArray(val)) {
                    val = JSON.stringify(val);
                }
                
                values.push(val);
                paramCount++;
            }
        }

        if (setClauses.length === 0) {
            return res.status(400).json({ success: false, error: 'No valid fields to update' });
        }

        values.push(id);
        const result = await db.query(
            `UPDATE staff SET ${setClauses.join(', ')} WHERE id = $${paramCount} RETURNING ${SAFE_STAFF_COLUMNS}`,
            values
        );
        invalidateStaffCaches();
        res.json({ success: true, staff: result.rows[0] });
    } catch (err: any) {
        console.error('Update Staff Error:', err);
        res.status(500).json({ success: false, error: err.message || 'Failed to update' });
    }
};

export const createStaff = async (req: Request, res: Response) => {
    try {
        const { name, email, role, phone, password, photo_url, address, place, phone_contacts, join_year, join_month, staff_id } = req.body;
        
        if (!name || name.trim().length === 0) {
            return res.status(400).json({ success: false, error: 'Name is required' });
        }

        const selectedRole = role || 'usthad';
        if (!STAFF_ROLES.includes(selectedRole)) {
            return res.status(400).json({ success: false, error: 'Invalid staff role' });
        }
        if (password && String(password).length < 8) {
            return res.status(400).json({ success: false, error: 'Password must be at least 8 characters' });
        }
        const finalEmail = email || `dummy-${Date.now()}@example.com`;

        let authUserId = null;

        // Create Supabase Auth user if password is provided
        if (password) {
            const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
                email: finalEmail,
                password: password,
                email_confirm: true,
            });

            if (authError || !authData.user) {
                console.error("Supabase Auth Error:", authError);
                return res.status(400).json({ success: false, error: authError?.message || 'Failed to create auth user' });
            }
            authUserId = authData.user.id;
        }

        let finalStaffId = staff_id || null;

        if (selectedRole === 'usthad' || selectedRole === 'vice_principal') {
            const currentYear = new Date().getFullYear().toString();
            const currentMonth = String(new Date().getMonth() + 1).padStart(2, '0');
            const yearStr = join_year || currentYear;
            const monthStr = String(join_month || currentMonth).padStart(2, '0');
            
            // Count total mentors/VPs to get sequence number
            const countRes = await db.query("SELECT COUNT(*) FROM staff WHERE role IN ('usthad', 'vice_principal')");
            const seq = String(parseInt(countRes.rows[0].count) + 1).padStart(2, '0');
            finalStaffId = `SR${seq}-${yearStr}-${monthStr}`;
        }

        // Optional: Wrap in a transaction
        const client = await db.getClient();
        try {
            await client.query('BEGIN');

            // 1. Insert into profiles if authUserId exists
            if (authUserId) {
                 await client.query(
                    `INSERT INTO profiles (id, role, full_name, updated_at) VALUES ($1, $2, $3, NOW()) ON CONFLICT(id) DO NOTHING`,
                    [authUserId, selectedRole, name.trim()]
                 );
            }

            const columns = ['name', 'role', 'staff_id'];
            const values: any[] = [name.trim(), selectedRole, finalStaffId];
            let paramCount = 4;

            const optionalFields: Record<string, any> = {
                email: finalEmail,
                phone: phone || null,
                profile_id: authUserId, // Set profile_id instead of password_hash
                photo_url: photo_url || null,
                address: address || null,
                place: place || null,
                phone_contacts: phone_contacts || [],
            };

            for (const [col, val] of Object.entries(optionalFields)) {
                if (val !== null && val !== undefined) {
                    columns.push(col);
                    
                    let insertVal = val;
                    // Stringify JSON array for pg driver
                    if (col === 'phone_contacts' && Array.isArray(insertVal)) {
                        insertVal = JSON.stringify(insertVal);
                    }
                    
                    values.push(insertVal);
                    paramCount++;
                }
            }

            const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
            const staffInsert = await client.query(
                `INSERT INTO staff (${columns.join(', ')}) VALUES (${placeholders}) RETURNING ${SAFE_STAFF_COLUMNS}`,
                values
            );

            await client.query('COMMIT');
            invalidateStaffCaches();
            res.json({ success: true, staffId: staffInsert.rows[0].id, staff: staffInsert.rows[0] });

        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }

    } catch (err: any) {
        console.error("Failed to create staff:", err);
        res.status(500).json({ success: false, error: err.message });
    }
};

export const getMyStudentsWithStats = async (req: Request, res: Response) => {
    try {
        const user = (req as any).user;
        // Get my staff record
        const ctx = await getDelegationContext(req);
        if (!ctx) {
            return res.status(404).json({ success: false, error: 'Staff profile not found' });
        }
        const staffId = ctx.staffId;
        const actingStudentId = ctx.studentId;
        const academicContext = await getAcademicYearContext(db, req.query.academic_year_id);

        const students = await getActiveMentorStudents(db, staffId, {
            academicYearId: academicContext.academicYearId,
            studentId: actingStudentId,
        });

        if (students.length === 0) {
            return res.json({ success: true, students: [] });
        }

        const { date } = req.query;
        const todayDate = date || new Date().toISOString().split('T')[0];
        const studentIds = students.map((s: any) => s.adm_no);
        const safeRows = (label: string, query: Promise<{ rows: any[] }>) =>
            query.catch((err: any) => {
                console.warn(`getMyStudentsWithStats: ${label} skipped:`, err.message);
                return { rows: [] as any[] };
            });

        // Fire all 5 dependent queries in parallel — none depend on each other,
        // they only depend on studentIds + staffId + todayDate. Previously each
        // awaited the next, costing ~5 sequential round-trips per request.
        const [activeLeaveResult, logsResult, attResult, outgoingDelegationsRes, lastHifzResult] = await Promise.all([
            safeRows('outside leave lookup', db.query(
                `SELECT student_id, leave_type, reason_category, remarks, end_datetime
                 FROM student_leaves
                 WHERE student_id = ANY($1) AND status = 'outside'
                   AND leave_type <> 'outdoor'
                 ORDER BY created_at DESC`,
                [studentIds]
            )),
            safeRows('today hifz logs lookup', db.query(
                `SELECT student_id, mode, start_page, end_page, juz_portion, entry_date
                 FROM hifz_logs WHERE student_id = ANY($1) AND entry_date = $2`,
                [studentIds, todayDate]
            )),
            safeRows('attendance marks lookup', db.query(
                `SELECT student_id, schedule_id, status FROM student_attendance_marks WHERE student_id = ANY($1) AND date = $2`,
                [studentIds, todayDate]
            )),
            safeRows('outgoing delegations lookup', db.query(
                `SELECT d.student_id, s.name as receiver_name
                 FROM mentor_delegations d
                 JOIN staff s ON d.to_staff_id = s.id
                 WHERE d.from_staff_id = $1 AND d.status = 'approved'`,
                [staffId]
            )),
            safeRows('last hifz lookup', db.query(
                `SELECT DISTINCT ON (student_id) student_id, surah_name, start_v, end_v, start_page, end_page, entry_date
                 FROM hifz_logs
                 WHERE student_id = ANY($1) AND mode = 'New Verses'
                 ORDER BY student_id, entry_date DESC, created_at DESC`,
                [studentIds]
            )),
        ]);

        // Build a map: student_id -> leave info
        const activeLeaveMap: Record<string, any> = {};
        activeLeaveResult.rows.forEach((l: any) => {
            if (!activeLeaveMap[l.student_id]) {
                activeLeaveMap[l.student_id] = l;
            }
        });

        const logsByStudent: Record<string, any[]> = {};
        logsResult.rows.forEach((log: any) => {
            if (!logsByStudent[log.student_id]) logsByStudent[log.student_id] = [];
            logsByStudent[log.student_id].push(log);
        });

        const attendanceByStudent: Record<string, any[]> = {};
        attResult.rows.forEach((mark: any) => {
            if (!attendanceByStudent[mark.student_id]) attendanceByStudent[mark.student_id] = [];
            attendanceByStudent[mark.student_id].push(mark);
        });
        const outgoingDelegations = outgoingDelegationsRes.rows;

        const lastHifzMap: Record<string, any> = {};
        lastHifzResult.rows.forEach(r => {
            lastHifzMap[r.student_id] = r;
        });

        // Enrich students with today's stats
        const enriched = students.map((student: any) => {
            const delegation = outgoingDelegations.find(d => 
                d.student_id === student.adm_no || d.student_id === null
            );
            
            const sLogs = logsByStudent[student.adm_no] || [];
            const sAtts = attendanceByStudent[student.adm_no] || [];

            let globalAttStatus = 'Pending';
            if (sAtts.length > 0) {
                // If present in ANY session today, mark them as Present globally on dashboard
                if (sAtts.some((a: any) => a.status === 'Present')) {
                    globalAttStatus = 'Present';
                } else if (sAtts.every((a: any) => a.status === 'Absent')) {
                    globalAttStatus = 'Absent';
                } else {
                    globalAttStatus = sAtts[0].status; // Leave, Late, etc
                }
            }

            let hifzLines = 0, revLines = 0, juzCount = 0;
            sLogs.forEach((log: any) => {
                // Helper: count lines/verses from a log entry
                const verseCount = (log.start_v && log.end_v) ? (log.end_v - log.start_v + 1) : 0;
                const pageCount = (log.start_page && log.end_page) ? (log.end_page - log.start_page + 1) : 0;
                // Use page count if available, otherwise fall back to verse count
                const lineScore = pageCount > 0 ? pageCount : verseCount;

                if (log.mode === 'New Verses') {
                    hifzLines += lineScore || 0.5; // 0.5 only if no page/verse data at all
                } else if (log.mode === 'Recent Revision') {
                    revLines += lineScore;
                } else if (log.mode === 'Juz Revision' || log.mode === 'Juz Revision (Old)') {
                    if (log.juz_portion === 'Full') juzCount += 1;
                    else if (log.juz_portion === '1st Half' || log.juz_portion === '2nd Half') juzCount += 0.5;
                    else if (log.juz_portion?.startsWith('Q')) juzCount += 0.25;
                    else juzCount += 1;
                }
            });
            const hifzPages = hifzLines;
            const revPages = revLines;

            const activeLeaveMeta = activeLeaveMap[student.adm_no];

            return {
                ...student,
                assigned_usthad: student.hifz_mentor_name ? { name: student.hifz_mentor_name } : null,
                hifz_mentor: student.hifz_mentor_name ? { name: student.hifz_mentor_name } : null,
                school_mentor: student.school_mentor_name ? { name: student.school_mentor_name } : null,
                madrasa_mentor: student.madrasa_mentor_name ? { name: student.madrasa_mentor_name } : null,
                is_outside: !!activeLeaveMeta,
                is_delegated: !!delegation,
                delegated_to: delegation ? delegation.receiver_name : null,
                last_hifz: lastHifzMap[student.adm_no] || null,
                active_leave: activeLeaveMeta ? {
                    leave_type: activeLeaveMeta.leave_type,
                    reason: activeLeaveMeta.reason_category || activeLeaveMeta.remarks || 'On Leave',
                    end_datetime: activeLeaveMeta.end_datetime,
                } : null,
                today_stats: sLogs.length > 0 || sAtts.length > 0 ? {
                    hifz: parseFloat(hifzPages.toFixed(1)),
                    revision: revPages,
                    juz: parseFloat(juzCount.toFixed(1)),
                    attendance: globalAttStatus,
                    session_marks: sAtts.map((a: any) => ({ schedule_id: a.schedule_id, status: a.status }))
                } : undefined
            };
        });

        res.json({ success: true, students: enriched });
    } catch (err) {
        console.error('Error fetching my students with stats:', err);
        res.status(500).json({ success: false, error: 'Failed' });
    }
};

export const getMyLeaves = async (req: Request, res: Response) => {
    try {
        const user = (req as any).user;
        const staffResult = await db.query(
            'SELECT id FROM staff WHERE email = $1 OR profile_id = $2 OR id = $2 LIMIT 1',
            [user.email, user.id]
        );
        if (staffResult.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Staff profile not found' });
        }
        const staffId = staffResult.rows[0].id;

        // Run both queries in parallel:
        // 1. Out-campus/personal leaves only for this mentor's assigned students
        // 2. ALL on-campus/internal leaves (campus-wide visibility for mentors)
        const [assignedLeavesRes, oncampusLeavesRes] = await Promise.all([
            db.query(
                `SELECT sl.*, s.name as student_name, s.standard, s.adm_no
                 FROM student_leaves sl
                 JOIN students s ON sl.student_id = s.adm_no
                 WHERE (s.hifz_mentor_id = $1 OR s.school_mentor_id = $1 OR s.madrasa_mentor_id = $1)
                   AND sl.leave_type NOT IN ('on-campus', 'internal', 'outdoor')
                 ORDER BY sl.created_at DESC`,
                [staffId]
            ),
            db.query(
                `SELECT sl.*, s.name as student_name, s.standard, s.adm_no
                 FROM student_leaves sl
                 JOIN students s ON sl.student_id = s.adm_no
                 WHERE sl.leave_type IN ('on-campus', 'internal')
                 ORDER BY sl.created_at DESC`,
                []
            ),
        ]);

        const allRows = [...assignedLeavesRes.rows, ...oncampusLeavesRes.rows]
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

        const leaves = allRows.map((row: any) => ({
            ...row,
            student: { name: row.student_name, standard: row.standard, adm_no: row.adm_no }
        }));

        res.json({ success: true, leaves });
    } catch (err) {
        console.error('Error fetching my leaves:', err);
        res.status(500).json({ success: false, error: 'Failed' });
    }
};
