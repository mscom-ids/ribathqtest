// src/components/reports/UnifiedReportView.tsx
"use client"

import React, { useState, useEffect } from "react"
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays } from "date-fns"
import { FileText, Calendar as CalendarIcon, Download, Loader2, AlertCircle, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import api from "@/lib/api"
import { cachedGet } from "@/lib/api-cache"
import { cn } from "@/lib/utils"

export default function UnifiedReportView() {
    const [students, setStudents] = useState<any[]>([])
    const [selectedStudent, setSelectedStudent] = useState<string>("")
    const [reportType, setReportType] = useState<"Weekly" | "Monthly" | "Yearly" | "Custom">("Monthly")
    const [dateRanges, setDateRanges] = useState({
        start: startOfMonth(subDays(new Date(), 2)),
        end: endOfMonth(subDays(new Date(), 2))
    })
    
    // UI state
    const [loading, setLoading] = useState(false)
    const [reportData, setReportData] = useState<any | null>(null)
    const [errorMsg, setErrorMsg] = useState("")

    useEffect(() => {
        let mounted = true
        // Load students dropdown
        cachedGet('/staff/me/students')
           .then(res => {
               if (!mounted) return
               if (res.data?.students) {
                   setStudents(res.data.students)
                   if (res.data.students.length === 1) { // Auto-select if only 1 student
                       setSelectedStudent(String(res.data.students[0].adm_no))
                   } else if (res.data.students.length > 0) {
                       setSelectedStudent(String(res.data.students[0].adm_no)) // Smart default
                   }
               }
           })
           .catch(() => {})
           
        return () => { mounted = false }
    }, [])

    const handleTypeChange = (val: string) => {
        const type = val as any
        setReportType(type)
        const now = new Date()
        
        // When switching types, auto-select the current/most recent valid block
        if (type === "Weekly") {
            setPeriodOffset("0")
            setDateRanges({ start: startOfWeek(now), end: endOfWeek(now) })
        } else if (type === "Monthly") {
            setPeriodOffset("0")
            const safeMonth = subDays(now, 5) 
            setDateRanges({ start: startOfMonth(safeMonth), end: endOfMonth(safeMonth) })
        } else if (type === "Yearly") {
            setPeriodOffset("0")
            setDateRanges({ start: startOfYear(now), end: endOfYear(now) })
        } else if (type === "Custom") {
            setDateRanges({ start: startOfMonth(now), end: endOfMonth(now) })
        }
    }

    // State for the semantic select (0 = current, 1 = 1 period ago, etc.)
    const [periodOffset, setPeriodOffset] = useState<string>("0")

    const handlePeriodChange = (val: string) => {
        setPeriodOffset(val)
        const offset = parseInt(val)
        const now = new Date()
        
        if (reportType === "Weekly") {
            const target = subDays(now, offset * 7)
            setDateRanges({ start: startOfWeek(target), end: endOfWeek(target) })
        } else if (reportType === "Monthly") {
            const target = new Date(now.getFullYear(), now.getMonth() - offset, 1)
            setDateRanges({ start: startOfMonth(target), end: endOfMonth(target) })
        } else if (reportType === "Yearly") {
            const target = new Date(now.getFullYear() - offset, 0, 1)
            setDateRanges({ start: startOfYear(target), end: endOfYear(target) })
        }
    }

    const handleGenerate = async () => {
        if (!selectedStudent) return setErrorMsg("Select a student first")
        
        setLoading(true)
        setErrorMsg("")
        setReportData(null)

        try {
            const res = await api.get('/reports/student-progress', {
                params: {
                    student_id: selectedStudent,
                    type: reportType,
                    start_date: format(dateRanges.start, 'yyyy-MM-dd'),
                    end_date: format(dateRanges.end, 'yyyy-MM-dd')
                }
            })

            if (res.data?.success) {
                setReportData(res.data.data)
            } else {
                setErrorMsg("Failed to generate report")
            }
        } catch (err: any) {
            setErrorMsg(err.response?.data?.error || "Error generating report")
        }
        setLoading(false)
    }

    const printPdf = () => {
        window.print();
    }

    const openWhatsApp = () => {
        const student = reportData?.student
        const phone = String(student?.parent_phone || "").replace(/\D/g, "")
        if (!phone) {
            setErrorMsg("No parent phone number is saved for this student.")
            return
        }

        const countryPhone = phone.length === 10 ? `91${phone}` : phone
        const performance = reportData?.performance
        const message = [
            "Assalamu Alaikum,",
            `${student.name}'s ${reportType.toLowerCase()} Hifz report (${format(dateRanges.start, 'MMMM yyyy')}):`,
            `New Verses: ${performance?.newVersePoints ?? 0}/20 points`,
            `Recent Revision: ${performance?.recentRevisionPoints ?? 0}/15 points`,
            `Juz Revision: ${performance?.juzPoints ?? 0}/15 points`,
            `Total: ${performance?.totalPoints ?? 0}/50 points (${performance?.percentage ?? 0}%)`,
            `Grade: ${performance?.grade || 'NO GRADE'}`,
        ].join("\n")
        window.open(`https://wa.me/${countryPhone}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer")
    }

    // Generator helpers for dropdowns
    const generateMonths = () => {
        const opts = []
        const now = new Date()
        for (let i = 0; i < 6; i++) {
            const temp = new Date(now.getFullYear(), now.getMonth() - i, 1)
            opts.push({ label: format(temp, 'MMMM yyyy'), value: String(i) })
        }
        return opts
    }

    const generateWeeks = () => {
        const opts = []
        const now = new Date()
        for (let i = 0; i < 4; i++) {
            const temp = subDays(now, i * 7)
            opts.push({ 
                label: i === 0 ? "Current Week" : i === 1 ? "Last Week" : `${i} Weeks Ago`, 
                value: String(i) 
            })
        }
        return opts
    }

    const generateYears = () => {
        const opts = []
        const now = new Date()
        for (let i = 0; i < 3; i++) {
            opts.push({ label: String(now.getFullYear() - i), value: String(i) })
        }
        return opts
    }

    return (
        <div className="max-w-5xl mx-auto space-y-6">
            <Card className="print:hidden border-slate-200 dark:border-slate-800 shadow-sm">
                <CardHeader className="pb-4">
                    <CardTitle className="text-xl">Generate Report</CardTitle>
                    <CardDescription>Select parameters to view progress reports</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                        <div className="space-y-2">
                            <Label>Student</Label>
                            <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                                <SelectTrigger className="bg-white w-full">
                                    <SelectValue placeholder="Select Student" />
                                </SelectTrigger>
                                <SelectContent>
                                    {students.map(s => (
                                        <SelectItem key={s.adm_no} value={String(s.adm_no)}>
                                            {s.name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            {errorMsg && !selectedStudent && (
                                <p className="text-xs text-red-500 mt-1 flex items-center">
                                    <AlertCircle className="h-3 w-3 mr-1" /> {errorMsg}
                                </p>
                            )}
                        </div>
                        <div className="space-y-2">
                            <Label>Report Type</Label>
                            <Select value={reportType} onValueChange={handleTypeChange}>
                                <SelectTrigger className="bg-white w-full">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Weekly">Weekly</SelectItem>
                                    <SelectItem value="Monthly">Monthly</SelectItem>
                                    <SelectItem value="Yearly">Yearly</SelectItem>
                                    <SelectItem value="Custom">Custom Range</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2 md:col-span-2">
                            <Label>Date Range</Label>
                            {reportType === "Custom" ? (
                                <div className="flex flex-col md:flex-row gap-2">
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className={cn("w-full bg-white justify-start text-left font-normal", !dateRanges.start && "text-muted-foreground")}>
                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                {dateRanges.start ? format(dateRanges.start, "PPP") : "Start Date"}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0" align="start">
                                            <Calendar mode="single" selected={dateRanges.start} onSelect={(d) => d && setDateRanges(p => ({ ...p, start: d }))} />
                                        </PopoverContent>
                                    </Popover>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className={cn("w-full bg-white justify-start text-left font-normal", !dateRanges.end && "text-muted-foreground")}>
                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                {dateRanges.end ? format(dateRanges.end, "PPP") : "End Date"}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0" align="start">
                                            <Calendar mode="single" selected={dateRanges.end} onSelect={(d) => d && setDateRanges(p => ({ ...p, end: d }))} />
                                        </PopoverContent>
                                    </Popover>
                                </div>
                            ) : (
                                <Select value={periodOffset} onValueChange={handlePeriodChange}>
                                    <SelectTrigger className="bg-white w-full">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {reportType === "Monthly" && generateMonths().map(o => (
                                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                                        ))}
                                        {reportType === "Weekly" && generateWeeks().map(o => (
                                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                                        ))}
                                        {reportType === "Yearly" && generateYears().map(o => (
                                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            )}
                        </div>
                    </div>
                    {errorMsg && selectedStudent && (
                        <div className="p-3 bg-red-50 text-red-600 rounded-lg flex items-center gap-2 text-sm mt-4">
                            <AlertCircle className="h-4 w-4" /> {errorMsg}
                        </div>
                    )}
                    <div className="mt-4 flex justify-end">
                      <Button onClick={handleGenerate} className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white" disabled={!selectedStudent || loading}>
                          {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FileText className="h-4 w-4 mr-2" />}
                          Generate Report
                      </Button>
                    </div>
                </CardContent>
            </Card>

            {/* PRINTABLE REGION */}
            {reportData && (
                <div className="bg-white text-slate-900 border rounded-xl overflow-hidden print:border-none print:shadow-none shadow-sm print:p-0 p-6 print:m-0 print:w-full print:block">
                    {/* Header */}
                    <div className="flex items-center justify-between border-b pb-6 print:border-b-2">
                        <div>
                            <h2 className="text-2xl font-black uppercase tracking-wider text-slate-800">Student Progress Report</h2>
                            <p className="text-sm text-slate-500 mt-1 font-medium">{format(dateRanges.start, 'MMM d, yyyy')} — {format(dateRanges.end, 'MMM d, yyyy')} ({reportType})</p>
                        </div>
                        <div className="flex items-center gap-2 print:hidden">
                            <Button variant="outline" onClick={openWhatsApp}>
                                <MessageCircle className="mr-2 h-4 w-4" /> Send to Parent
                            </Button>
                            <Button variant="outline" onClick={printPdf}>
                                <Download className="mr-2 h-4 w-4" /> Download PDF
                            </Button>
                        </div>
                    </div>

                    <div className="mt-8 space-y-8">
                        {/* Student Meta */}
                        <div className="bg-slate-50 print:bg-transparent border print:border-slate-300 rounded-xl p-5 print:p-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                                <div>
                                    <p className="text-xs text-slate-500 uppercase font-semibold">Student Name</p>
                                    <p className="font-bold text-slate-900 mt-1">{reportData.student.name || "N/A"}</p>
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500 uppercase font-semibold">ID / Batch</p>
                                    <p className="font-bold text-slate-900 mt-1">{reportData.student.adm_no} • {reportData.student.batch_year}</p>
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500 uppercase font-semibold">Class</p>
                                    <p className="font-bold text-slate-900 mt-1">{reportData.student.standard || "N/A"}</p>
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500 uppercase font-semibold">Mentor</p>
                                    <p className="font-bold text-slate-900 mt-1">{reportData.student.hifz_mentor || "N/A"}</p>
                                </div>
                            </div>
                        </div>

                        {/* Attendance Summary */}
                        <div>
                            <h3 className="text-lg font-bold border-b print:border-slate-300 pb-2 mb-4 text-slate-800">Session Attendance</h3>
                            {reportData.attendance_totals && (
                                <div className="mb-4 grid grid-cols-2 md:grid-cols-4 gap-3">
                                    <div className="rounded-lg border border-slate-200 p-3 print:border-slate-300">
                                        <p className="text-[10px] uppercase font-bold text-slate-500">Cancelled</p>
                                        <p className="text-xl font-black text-slate-800">{reportData.attendance_totals.cancelledClasses}</p>
                                    </div>
                                    <div className="rounded-lg border border-emerald-100 bg-emerald-50 p-3 print:border-slate-300 print:bg-transparent">
                                        <p className="text-[10px] uppercase font-bold text-emerald-700">Attended</p>
                                        <p className="text-xl font-black text-emerald-700">{reportData.attendance_totals.attendedClasses}</p>
                                    </div>
                                    <div className="rounded-lg border border-red-100 bg-red-50 p-3 print:border-slate-300 print:bg-transparent">
                                        <p className="text-[10px] uppercase font-bold text-red-700">Not attended</p>
                                        <p className="text-xl font-black text-red-700">{reportData.attendance_totals.notAttendedClasses}</p>
                                    </div>
                                    <div className="rounded-lg border border-slate-200 p-3 print:border-slate-300">
                                        <p className="text-[10px] uppercase font-bold text-slate-500">Counted</p>
                                        <p className="text-xl font-black text-slate-800">{reportData.attendance_totals.effectiveClasses}</p>
                                    </div>
                                </div>
                            )}
                            {reportData.attendance.length > 0 ? (() => {
                                // Deduplicate by session name — merge present/absent/total for same-named sessions
                                const merged = new Map<string, any>()
                                reportData.attendance.forEach((att: any) => {
                                    const rawSession = (att.session || 'Session').trim()
                                    const key = rawSession.toLowerCase()
                                    if (merged.has(key)) {
                                        const ex = merged.get(key)
                                        ex.present += Number(att.present || 0)
                                        ex.late += Number(att.late || 0)
                                        ex.absent += Number(att.absent || 0)
                                        ex.leave += Number(att.leave || 0)
                                        ex.attended += Number(att.attended ?? att.present ?? 0)
                                        ex.not_attended += Number(att.not_attended ?? att.absent ?? 0)
                                        ex.cancelled += Number(att.cancelled || 0)
                                        ex.total += Number(att.total || att.effective_total || 0)
                                        ex.planned += Number(att.planned || att.total || 0)
                                        ex.effective_total += Number(att.effective_total || att.total || 0)
                                    } else {
                                        // Normalize "HIfz" typo to "Hifz" for display
                                        const cleanSession = rawSession.replace(/^hifz/i, 'Hifz')
                                        merged.set(key, {
                                            ...att,
                                            session: cleanSession,
                                            present: Number(att.present || 0),
                                            late: Number(att.late || 0),
                                            absent: Number(att.absent || 0),
                                            leave: Number(att.leave || 0),
                                            attended: Number(att.attended ?? att.present ?? 0),
                                            not_attended: Number(att.not_attended ?? att.absent ?? 0),
                                            cancelled: Number(att.cancelled || 0),
                                            total: Number(att.total || att.effective_total || 0),
                                            planned: Number(att.planned || att.total || 0),
                                            effective_total: Number(att.effective_total || att.total || 0),
                                        })
                                    }
                                })
                                return (
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        {Array.from(merged.values()).map((att: any, i: number) => {
                                            const countedTotal = att.effective_total || att.total || 0
                                            const pct = countedTotal > 0 ? Math.round((att.attended / countedTotal) * 100) : 0
                                            return (
                                                <div key={i} className="border border-slate-200 rounded-lg p-4 print:border-slate-300 print:break-inside-avoid">
                                                    <p className="text-sm font-bold text-slate-700 mb-2">{att.session}</p>
                                                    <div className="flex justify-between items-end">
                                                        <div className="space-y-1">
                                                            <p className="text-xs text-slate-600">Attended: <span className="font-semibold text-emerald-600">{att.attended}</span></p>
                                                            <p className="text-xs text-slate-600">Not attended: <span className="font-semibold text-red-600">{att.not_attended}</span></p>
                                                            <p className="text-xs text-slate-600">Cancelled: <span className="font-semibold text-slate-500">{att.cancelled}</span></p>
                                                        </div>
                                                        <div className="text-right">
                                                            <span className="text-2xl font-black text-slate-800">{pct}%</span>
                                                            <p className="text-[10px] text-slate-400 font-medium">counted: {countedTotal}</p>
                                                            <p className="text-[10px] text-slate-400 font-medium">scheduled: {att.planned}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            )
                                        })}
                                    </div>
                                )
                            })() : (
                                <div className="bg-slate-50 print:bg-transparent rounded-lg p-6 text-center border-dashed border-2 print:border-slate-300 text-slate-500 text-sm">
                                    No attendance data recorded in this timeframe.
                                </div>
                            )}
                        </div>

                        {reportData.performance && (
                            <div className="print:break-inside-avoid">
                                <h3 className="text-lg font-bold border-b print:border-slate-300 pb-2 mb-4 text-slate-800">Performance & Grade</h3>
                                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                                    <div className="rounded-lg border border-blue-100 bg-blue-50 p-4 print:border-slate-300 print:bg-transparent">
                                        <p className="text-xs font-semibold text-blue-700">New Verses</p>
                                        <p className="mt-1 text-2xl font-black text-blue-900">{reportData.performance.newVersePoints}/20</p>
                                    </div>
                                    <div className="rounded-lg border border-orange-100 bg-orange-50 p-4 print:border-slate-300 print:bg-transparent">
                                        <p className="text-xs font-semibold text-orange-700">Recent Revision</p>
                                        <p className="mt-1 text-2xl font-black text-orange-900">{reportData.performance.recentRevisionPoints}/15</p>
                                    </div>
                                    <div className="rounded-lg border border-violet-100 bg-violet-50 p-4 print:border-slate-300 print:bg-transparent">
                                        <p className="text-xs font-semibold text-violet-700">Juz Revision</p>
                                        <p className="mt-1 text-2xl font-black text-violet-900">{reportData.performance.juzPoints}/15</p>
                                    </div>
                                    <div className="rounded-lg border border-emerald-100 bg-emerald-50 p-4 print:border-slate-300 print:bg-transparent">
                                        <p className="text-xs font-semibold text-emerald-700">Total</p>
                                        <p className="mt-1 text-2xl font-black text-emerald-900">{reportData.performance.totalPoints}/50</p>
                                        <p className="text-xs text-emerald-700">{reportData.performance.percentage}%</p>
                                    </div>
                                    <div className="rounded-lg border border-slate-200 p-4 print:border-slate-300">
                                        <p className="text-xs font-semibold text-slate-600">Grade</p>
                                        <p className="mt-1 text-2xl font-black text-slate-900">{reportData.performance.grade}</p>
                                        <p className="text-xs text-slate-500">{reportData.performance.totalClassDays} point days</p>
                                    </div>
                                </div>
                            </div>
                        )}
                        {/* Hifz Progress Metrics */}
                        <div className="print:break-inside-avoid">
                            <h3 className="text-lg font-bold border-b print:border-slate-300 pb-2 mb-4 text-slate-800">Hifz Activity</h3>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {(()=>{
                                    const newVerses = reportData.hifz_logs_agg.find((l:any) => l.mode === 'New Verses')
                                    const juzRev = reportData.hifz_logs_agg.find((l:any) => l.mode === 'Juz Revision')
                                    const exactNewPages = Number(reportData.hifz_activity?.new_pages_recited ?? newVerses?.pages_recited ?? 0)
                                    const completedLifetimeJuz = Number(reportData.hifz_activity?.completed_lifetime_juz ?? 0)

                                    return (
                                        <>
                                           <div className="bg-blue-50 text-blue-900 border border-blue-100 print:border-slate-300 print:bg-transparent rounded-lg p-4">
                                               <p className="text-xs text-blue-600/80 print:text-slate-500 uppercase font-bold tracking-wider mb-1">New Pages Recited</p>
                                               <p className="text-3xl font-black">{exactNewPages}</p>
                                               <p className="text-[10px] mt-1 text-blue-600/60 font-medium print:text-slate-400">Exact Mushaf page coverage</p>
                                           </div>
                                           <div className="bg-orange-50 text-orange-900 border border-orange-100 print:border-slate-300 print:bg-transparent rounded-lg p-4">
                                               <p className="text-xs text-orange-600/80 print:text-slate-500 uppercase font-bold tracking-wider mb-1">Revision Days</p>
                                               <p className="text-3xl font-black">{reportData.revision_days}</p>
                                               <p className="text-[10px] mt-1 text-orange-600/60 font-medium print:text-slate-400">Consistent daily reviews</p>
                                           </div>
                                           <div className="bg-emerald-50 text-emerald-900 border border-emerald-100 print:border-slate-300 print:bg-transparent rounded-lg p-4">
                                               <p className="text-xs text-emerald-600/80 print:text-slate-500 uppercase font-bold tracking-wider mb-1">Juz Revisions</p>
                                               <p className="text-3xl font-black">{juzRev?.entry_count || 0}</p>
                                               <p className="text-[10px] mt-1 text-emerald-600/60 font-medium print:text-slate-400">Total logged sessions</p>
                                           </div>
                                           <div className="bg-purple-50 text-purple-900 border border-purple-100 print:border-slate-300 print:bg-transparent rounded-lg p-4">
                                               <p className="text-xs text-purple-600/80 print:text-slate-500 uppercase font-bold tracking-wider mb-1">Total Lifetime Juz</p>
                                               <p className="text-3xl font-black">
                                                    {completedLifetimeJuz}
                                               </p>
                                               <p className="text-[10px] mt-1 text-purple-600/60 font-medium print:text-slate-400">Completed entirely</p>
                                           </div>
                                        </>
                                    )
                                })()}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
